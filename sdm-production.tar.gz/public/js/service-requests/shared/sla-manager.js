console.log('sla-manager.js loaded successfully');

class SLAManager {
    constructor() {
        console.log('SLAManager initialized');
        this.init();
    }

    init() {
        console.log('SLAManager init called');
        // Funcionalidad básica de SLA
    }
}
