<?php $__env->startSection('title', 'Gestión de Solicitantes'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">Gestión de Solicitantes</h4>
            </div>
        </div>
    </div>

    <!-- Estadísticas -->
    <div class="row mb-3">
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h5 class="card-title">Total</h5>
                    <h2><?php echo e(\App\Models\Requester::count()); ?></h2>
                    <p class="card-text">Solicitantes</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h5 class="card-title">Activos</h5>
                    <h2><?php echo e(\App\Models\Requester::active()->count()); ?></h2>
                    <p class="card-text">Solicitantes activos</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <h5 class="card-title">Con Solicitudes</h5>
                    <h2><?php echo e(\App\Models\Requester::has('serviceRequests')->count()); ?></h2>
                    <p class="card-text">Con solicitudes creadas</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Filtros y Búsqueda -->
    <div class="row mb-3">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                            <form action="<?php echo e(route('requester-management.index')); ?>" method="GET">
                                <div class="input-group">
                                    <input type="text" name="search" class="form-control"
                                           placeholder="Buscar por nombre, email, departamento o cargo..."
                                           value="<?php echo e(request('search')); ?>">
                                    <select name="status" class="form-select" style="max-width: 200px;">
                                        <option value="all">Todos</option>
                                        <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>Activos</option>
                                        <option value="inactive" <?php echo e(request('status') == 'inactive' ? 'selected' : ''); ?>>Inactivos</option>
                                    </select>
                                    <button type="submit" class="btn btn-primary">Buscar</button>
                                    <a href="<?php echo e(route('requester-management.index')); ?>" class="btn btn-secondary">Limpiar</a>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-4 text-end">
                            <a href="<?php echo e(route('requester-management.create')); ?>" class="btn btn-success">
                                <i class="fas fa-plus me-2"></i>Nuevo Solicitante
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Lista -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Contacto</th>
                                    <th>Departamento</th>
                                    <th>Cargo</th>
                                    <th>Solicitudes</th>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $requesters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo e($requester->name); ?></strong>
                                            <?php if($requester->email): ?>
                                                <br><small class="text-muted"><?php echo e($requester->email); ?></small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($requester->phone): ?>
                                                <i class="fas fa-phone text-muted me-1"></i>
                                                <?php echo e($requester->phone); ?>

                                            <?php else: ?>
                                                <span class="text-muted">N/A</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($requester->department ?? 'N/A'); ?></td>
                                        <td><?php echo e($requester->position ?? 'N/A'); ?></td>
                                        <td>
                                            <span class="badge bg-primary"><?php echo e($requester->service_requests_count); ?></span>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo e($requester->is_active ? 'success' : 'danger'); ?>">
                                                <?php echo e($requester->is_active ? 'Activo' : 'Inactivo'); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <a href="<?php echo e(route('requester-management.show', $requester)); ?>"
                                                   class="btn btn-info" title="Ver detalle">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="<?php echo e(route('requester-management.edit', $requester)); ?>"
                                                   class="btn btn-warning" title="Editar">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <form action="<?php echo e(route('requester-management.toggle-status', $requester)); ?>"
                                                      method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PATCH'); ?>
                                                    <button type="submit" class="btn btn-<?php echo e($requester->is_active ? 'warning' : 'success'); ?>"
                                                            title="<?php echo e($requester->is_active ? 'Desactivar' : 'Activar'); ?>">
                                                        <i class="fas fa-<?php echo e($requester->is_active ? 'times' : 'check'); ?>"></i>
                                                    </button>
                                                </form>
                                                <?php if($requester->can_be_deleted): ?>
                                                    <form action="<?php echo e(route('requester-management.destroy', $requester)); ?>"
                                                          method="POST" class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger"
                                                                onclick="return confirm('¿Está seguro de eliminar este solicitante?')"
                                                                title="Eliminar">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center py-4">
                                            <div class="text-muted">
                                                <i class="fas fa-users fa-2x mb-2"></i>
                                                <p>No se encontraron solicitantes</p>
                                                <a href="<?php echo e(route('requester-management.create')); ?>" class="btn btn-primary">
                                                    Crear primer solicitante
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Paginación -->
                    <div class="d-flex justify-content-center mt-3">
                        <?php echo e($requesters->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sdm\resources\views/requester-management/index.blade.php ENDPATH**/ ?>