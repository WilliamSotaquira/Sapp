<!-- Header Principal -->
<div class="bg-gradient-to-r from-blue-600 to-indigo-700 shadow-xl rounded-2xl overflow-hidden mb-8">
    <div class="px-8 py-6 text-white">
        <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between">
            <div class="flex items-center space-x-4 mb-4 lg:mb-0">
                <div class="bg-white/20 p-3 rounded-2xl backdrop-blur-sm">
                    <i class="fas fa-tasks text-2xl"></i>
                </div>
                <div>
                    <h1 class="text-2xl font-bold">Solicitudes de Servicio</h1>
                    <p class="text-blue-100 opacity-90 mt-1">Gestión y seguimiento de todas las solicitudes del sistema</p>
                </div>
            </div>
            <?php if (isset($component)) { $__componentOriginal097a0bde368aa742f77126c1bf6e8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal097a0bde368aa742f77126c1bf6e8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.index.header.filters-badge','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.index.header.filters-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal097a0bde368aa742f77126c1bf6e8561)): ?>
<?php $attributes = $__attributesOriginal097a0bde368aa742f77126c1bf6e8561; ?>
<?php unset($__attributesOriginal097a0bde368aa742f77126c1bf6e8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal097a0bde368aa742f77126c1bf6e8561)): ?>
<?php $component = $__componentOriginal097a0bde368aa742f77126c1bf6e8561; ?>
<?php unset($__componentOriginal097a0bde368aa742f77126c1bf6e8561); ?>
<?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\sdm\resources\views/components/service-requests/index/header/main-header.blade.php ENDPATH**/ ?>