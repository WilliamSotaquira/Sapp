<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['serviceRequest']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['serviceRequest']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden">
    <div class="bg-gradient-to-r from-blue-50 to-indigo-50 px-6 py-4 border-b border-blue-100">
        <h3 class="text-lg font-bold text-gray-800 flex items-center">
            <i class="fas fa-align-left text-blue-600 mr-3"></i>
            Descripción Detallada
        </h3>
    </div>
    <div class="p-6">
        <div class="space-y-4">
            <div>
                <label class="text-sm font-medium text-gray-500 block mb-2">Título</label>
                <p class="text-gray-900 font-semibold text-lg"><?php echo e($serviceRequest->title); ?></p>
            </div>

            <div>
                <label class="text-sm font-medium text-gray-500 block mb-2">Descripción</label>
                <div class="prose max-w-none">
                    <p class="text-gray-700 whitespace-pre-line"><?php echo e($serviceRequest->description); ?></p>
                </div>
            </div>

            <?php if($serviceRequest->additional_notes): ?>
            <div>
                <label class="text-sm font-medium text-gray-500 block mb-2">Notas Adicionales</label>
                <div class="prose max-w-none">
                    <p class="text-gray-700 whitespace-pre-line"><?php echo e($serviceRequest->additional_notes); ?></p>
                </div>
            </div>
            <?php endif; ?>

            <?php if($serviceRequest->solution_details): ?>
            <div>
                <label class="text-sm font-medium text-gray-500 block mb-2">Detalles de la Solución</label>
                <div class="prose max-w-none">
                    <p class="text-gray-700 whitespace-pre-line"><?php echo e($serviceRequest->solution_details); ?></p>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\sdm\resources\views/components/service-requests/show/content/description-panel.blade.php ENDPATH**/ ?>