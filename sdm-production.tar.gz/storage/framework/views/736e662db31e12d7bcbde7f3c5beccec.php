<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title><?php echo e($title); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            line-height: 1.4;
            color: #000;
            margin: 0;
            padding: 20px;
        }

        .header {
            text-align: center;
            border-bottom: 2px solid #000;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }

        .header h1 {
            margin: 0;
            font-size: 18px;
            font-weight: bold;
        }

        .section {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
        }

        .section-title {
            font-weight: bold;
            margin-bottom: 10px;
            padding-bottom: 5px;
            border-bottom: 1px solid #ccc;
        }

        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }

        .info-item {
            margin-bottom: 5px;
        }

        .info-label {
            font-weight: bold;
        }

        .status {
            font-weight: bold;
            text-transform: uppercase;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            font-size: 11px;
        }

        .table th,
        .table td {
            border: 1px solid #ccc;
            padding: 6px;
            text-align: left;
        }

        .table th {
            font-weight: bold;
            background-color: #f5f5f5;
        }

        .files-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            margin-top: 10px;
        }

        .file-container {
            text-align: center;
            border: 1px solid #ccc;
            padding: 8px;
        }

        .evidence-image {
            max-width: 100%;
            max-height: 500px;
            height: auto;
            display: block;
            margin: 0 auto;
        }

        .file-icon {
            font-size: 24px;
            margin-bottom: 5px;
        }

        .file-title {
            font-size: 10px;
            margin-top: 5px;
            font-weight: bold;
        }

        .footer {
            margin-top: 20px;
            text-align: center;
            font-size: 10px;
            border-top: 1px solid #ccc;
            padding-top: 10px;
        }

        .no-data {
            text-align: center;
            font-style: italic;
            padding: 20px;
            color: #666;
        }

        .file-error {
            background: #f5f5f5;
            padding: 20px;
            text-align: center;
            border: 1px dashed #ccc;
            font-size: 10px;
        }

        .debug-info {
            background: #fffacd;
            padding: 5px;
            margin: 5px 0;
            font-size: 9px;
            border-left: 3px solid #ffd700;
        }

        .system-evidence {
            background-color: #f0f8ff;
        }
    </style>
</head>
<body>
    <!-- Encabezado -->
    <div class="header">
        <h1>REPORTE DE SOLICITUD DE SERVICIO</h1>
        <div><strong>Ticket:</strong> #<?php echo e($serviceRequest->ticket_number); ?></div>
        <div><strong>Generado el:</strong> <?php echo e($generated_at); ?></div>
    </div>

    <!-- Información Básica -->
    <div class="section">
        <div class="section-title">INFORMACIÓN BÁSICA</div>
        <div class="info-grid">
            <div class="info-item">
                <span class="info-label">Ticket:</span> #<?php echo e($serviceRequest->ticket_number); ?>

            </div>
            <div class="info-item">
                <span class="info-label">Estado:</span>
                <span class="status"><?php echo e($serviceRequest->status); ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Solicitante:</span> <?php echo e($serviceRequest->requester->name ?? 'N/A'); ?>

            </div>
            <div class="info-item">
                <span class="info-label">Técnico:</span> <?php echo e($serviceRequest->assignedTechnician->name ?? 'No asignado'); ?>

            </div>
            <div class="info-item">
                <span class="info-label">Título:</span> <?php echo e($serviceRequest->title ?? 'Sin título'); ?>

            </div>
            <div class="info-item">
                <span class="info-label">Sub-servicio:</span> <?php echo e($serviceRequest->subService->name ?? 'N/A'); ?>

            </div>
            <div class="info-item">
                <span class="info-label">Fecha Creación:</span> <?php echo e($serviceRequest->created_at->format('d/m/Y H:i')); ?>

            </div>
        </div>
    </div>

    <!-- Evidencias -->
    <div class="section">
        <div class="section-title">EVIDENCIAS (<?php echo e($serviceRequest->evidences->count()); ?>)</div>

        <?php if($serviceRequest->evidences && $serviceRequest->evidences->count() > 0): ?>
            <!-- Lista de todas las evidencias -->
            <table class="table">
                <thead>
                    <tr>
                        <th>Tipo</th>
                        <th>Título</th>
                        <th>Descripción</th>
                        <th>Fecha</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $serviceRequest->evidences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evidence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="<?php echo e($evidence->evidence_type === 'SISTEMA' ? 'system-evidence' : ''); ?>">
                        <td><?php echo e($evidence->evidence_type ?? 'N/A'); ?></td>
                        <td><?php echo e($evidence->title ?? 'Sin título'); ?></td>
                        <td><?php echo e($evidence->description ?? 'Sin descripción'); ?></td>
                        <td><?php echo e($evidence->created_at->format('d/m/Y H:i')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <!-- Archivos adjuntos (imágenes y otros) -->
            <?php if($serviceRequest->evidences->where('file_path', '!=', null)->count() > 0): ?>
            <div style="margin-top: 15px;">
                <div style="font-weight: bold; margin-bottom: 10px;">ARCHIVOS ADJUNTOS:</div>
                <div class="files-grid">
                    <?php $__currentLoopData = $serviceRequest->evidences->where('file_path', '!=', null); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evidence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="file-container">
                            <?php if(isset($evidence->is_image) && $evidence->is_image && $evidence->base64_content): ?>
                                <!-- Es una imagen -->
                                <img src="<?php echo e($evidence->base64_content); ?>"
                                     alt="<?php echo e($evidence->title ?? 'Archivo ' . $loop->iteration); ?>"
                                     class="evidence-image">
                                <div class="file-title" style="color: green;">
                                    📷 <?php echo e($evidence->title ?? 'Imagen ' . $loop->iteration); ?>

                                </div>
                            <?php elseif(isset($evidence->file_found) && $evidence->file_found): ?>
                                <!-- Es otro tipo de archivo -->
                                <div class="file-icon">📄</div>
                                <div class="file-title" style="color: blue;">
                                    📄 <?php echo e($evidence->title ?? 'Archivo ' . $loop->iteration); ?>

                                </div>
                                <div style="font-size: 9px; color: #666;">
                                    <?php echo e($evidence->file_path); ?>

                                </div>
                            <?php else: ?>
                                <!-- Archivo no encontrado -->
                                <div class="file-error">
                                    <strong>✗ ARCHIVO NO ENCONTRADO</strong><br>
                                    <small><?php echo e($evidence->file_path ?? 'No especificado'); ?></small>
                                </div>
                                <div class="file-title" style="color: red;">
                                    ✗ <?php echo e($evidence->title ?? 'Archivo ' . $loop->iteration); ?>

                                </div>
                            <?php endif; ?>

                            <?php if($evidence->description): ?>
                            <div style="font-size: 9px; margin-top: 3px;">
                                <?php echo e(Str::limit($evidence->description, 40)); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="no-data">No hay evidencias registradas para esta solicitud</div>
        <?php endif; ?>
    </div>

    <!-- Pie de página -->
    <div class="footer">
        Reporte generado automáticamente por el Sistema de Gestión de Servicios
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\sdm\resources\views/reports/service-request-pdf.blade.php ENDPATH**/ ?>