<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['serviceRequests']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['serviceRequests']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="bg-white rounded-lg shadow-sm border border-gray-200" role="region" aria-labelledby="requests-table-title">
    <!-- Header Compacto -->
    <div class="bg-gray-50 px-4 py-3 border-b border-gray-200">
        <div class="flex items-center justify-between">
            <h3 id="requests-table-title" class="text-base font-semibold text-gray-800 flex items-center">
                <i class="fas fa-tasks text-blue-500 mr-2 text-sm"></i>
                Solicitudes de Servicio
                <span class="ml-2 text-sm font-medium text-gray-500 bg-gray-200 px-2 py-0.5 rounded-full">
                    <?php echo e($serviceRequests->total()); ?>

                </span>
            </h3>

            <!-- Estado Resumido -->
            <div class="flex items-center gap-3 text-xs">
                <span class="flex items-center text-yellow-600">
                    <span class="w-1.5 h-1.5 bg-yellow-500 rounded-full mr-1"></span>
                    <?php echo e($pendingCount ?? 0); ?>

                </span>
                <span class="flex items-center text-red-600">
                    <span class="w-1.5 h-1.5 bg-red-500 rounded-full mr-1"></span>
                    <?php echo e($criticalCount ?? 0); ?>

                </span>
                <span class="flex items-center text-green-600">
                    <span class="w-1.5 h-1.5 bg-green-500 rounded-full mr-1"></span>
                    <?php echo e($resolvedCount ?? 0); ?>

                </span>
            </div>
        </div>
    </div>

    <!-- Contenido Compacto -->
    <div class="p-4">
        <?php if($serviceRequests->count() > 0): ?>
            <div class="overflow-x-auto">
                <!-- Tabla Compacta -->
                <table class="min-w-full text-sm" aria-describedby="table-instructions">
                    <thead class="bg-gray-50 text-xs text-gray-700 uppercase">
                        <tr>
                            <th class="px-3 py-2 text-left font-medium">Ticket</th>
                            <th class="px-3 py-2 text-left font-medium w-1/5">Solicitud</th>
                            <th class="px-3 py-2 text-left font-medium w-1/5">Servicio</th>
                            <th class="px-3 py-2 text-left font-medium">Prioridad</th>
                            <th class="px-3 py-2 text-left font-medium">Estado</th>
                            <th class="px-3 py-2 text-left font-medium">Solicitante</th>
                            <th class="px-3 py-2 text-left font-medium">Fecha</th>
                            <th class="px-3 py-2 text-left font-medium">Acciones</th>
                        </tr>
                    </thead>

                    <tbody class="divide-y divide-gray-200">
                        <?php $__currentLoopData = $serviceRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if (isset($component)) { $__componentOriginala1fc7c10882a7bf2af189d0f9d439421 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala1fc7c10882a7bf2af189d0f9d439421 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.index.content.table-row','data' => ['request' => $request]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.index.content.table-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['request' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($request)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala1fc7c10882a7bf2af189d0f9d439421)): ?>
<?php $attributes = $__attributesOriginala1fc7c10882a7bf2af189d0f9d439421; ?>
<?php unset($__attributesOriginala1fc7c10882a7bf2af189d0f9d439421); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala1fc7c10882a7bf2af189d0f9d439421)): ?>
<?php $component = $__componentOriginala1fc7c10882a7bf2af189d0f9d439421; ?>
<?php unset($__componentOriginala1fc7c10882a7bf2af189d0f9d439421); ?>
<?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <!-- Estado Vacío Compacto -->
            <div class="text-center py-8">
                <i class="fas fa-inbox text-gray-300 text-3xl mb-3"></i>
                <p class="text-gray-500 text-sm">No se encontraron solicitudes</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Footer Compacto -->
    <?php if($serviceRequests->hasPages()): ?>
        <div class="bg-gray-50 px-4 py-2 border-t border-gray-200">
            <div class="flex items-center justify-between text-xs text-gray-500">
                <span>Página <?php echo e($serviceRequests->currentPage()); ?> de <?php echo e($serviceRequests->lastPage()); ?></span>
                <span>Actualizado: <?php echo e(now()->format('H:i')); ?></span>
            </div>
        </div>
    <?php endif; ?>
</div>

<style>
    /* Mejoras de densidad */
    .min-w-full th,
    .min-w-full td {
        padding: 0.5rem 0.75rem;
    }

    /* Estados de enfoque para accesibilidad */
    tr:focus {
        outline: 2px solid #3b82f6;
        background-color: #eff6ff;
    }

    /* Hover sutil */
    tr:hover {
        background-color: #f9fafb;
    }
</style>
<?php /**PATH C:\xampp\htdocs\sdm\resources\views/components/service-requests/index/content/requests-table.blade.php ENDPATH**/ ?>