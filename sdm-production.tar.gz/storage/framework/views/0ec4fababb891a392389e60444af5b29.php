<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['serviceRequest']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['serviceRequest']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div id="evidences-section" class="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden">
    <div class="bg-gradient-to-r from-amber-50 to-orange-50 px-6 py-4 border-b border-amber-100">
        <div class="flex items-center justify-between">
            <div class="flex items-center">
                <i class="fas fa-images text-amber-600 mr-3 text-xl"></i>
                <div>
                    <h3 class="text-lg font-bold text-gray-800">Evidencias y Archivos Adjuntos</h3>
                    <p class="text-sm text-amber-700 mt-1">Documentos, imágenes y archivos relacionados con la solicitud</p>
                </div>
            </div>
            <div class="text-right">
                <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-semibold bg-amber-100 text-amber-800">
                    <i class="fas fa-file-alt mr-2"></i>
                    <?php echo e($serviceRequest->evidences->count()); ?> archivo<?php echo e($serviceRequest->evidences->count() !== 1 ? 's' : ''); ?>

                </span>
            </div>
        </div>
    </div>

    <div class="p-6">
        <?php if($serviceRequest->evidences->count() > 0): ?>
            <!-- Estadísticas rápidas -->
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <?php
                    $imagesCount = $serviceRequest->evidences->where('file_type', 'like', 'image%')->count();
                    $documentsCount = $serviceRequest->evidences->whereIn('file_type', ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'])->count();
                    $othersCount = $serviceRequest->evidences->count() - $imagesCount - $documentsCount;
                    $totalSize = $serviceRequest->evidences->sum('file_size');
                ?>

                <div class="bg-blue-50 rounded-lg p-3 text-center border border-blue-100">
                    <div class="text-blue-600 mb-1">
                        <i class="fas fa-file-image text-lg"></i>
                    </div>
                    <div class="text-lg font-bold text-gray-800"><?php echo e($imagesCount); ?></div>
                    <div class="text-xs text-gray-600">Imágenes</div>
                </div>

                <div class="bg-green-50 rounded-lg p-3 text-center border border-green-100">
                    <div class="text-green-600 mb-1">
                        <i class="fas fa-file-pdf text-lg"></i>
                    </div>
                    <div class="text-lg font-bold text-gray-800"><?php echo e($documentsCount); ?></div>
                    <div class="text-xs text-gray-600">Documentos</div>
                </div>

                <div class="bg-purple-50 rounded-lg p-3 text-center border border-purple-100">
                    <div class="text-purple-600 mb-1">
                        <i class="fas fa-file-alt text-lg"></i>
                    </div>
                    <div class="text-lg font-bold text-gray-800"><?php echo e($othersCount); ?></div>
                    <div class="text-xs text-gray-600">Otros</div>
                </div>

                <div class="bg-amber-50 rounded-lg p-3 text-center border border-amber-100">
                    <div class="text-amber-600 mb-1">
                        <i class="fas fa-hdd text-lg"></i>
                    </div>
                    <div class="text-lg font-bold text-gray-800"><?php echo e(number_format($totalSize / 1024 / 1024, 1)); ?>MB</div>
                    <div class="text-xs text-gray-600">Total</div>
                </div>
            </div>

            <!-- Grid de evidencias -->
            <div class="mb-6">
                <h4 class="text-md font-semibold text-gray-700 mb-4 flex items-center">
                    <i class="fas fa-folder-open text-amber-500 mr-2"></i>
                    Archivos adjuntos
                </h4>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <?php $__currentLoopData = $serviceRequest->evidences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evidence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal805975d0e20b8350387489926caabc49 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal805975d0e20b8350387489926caabc49 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.show.evidences.evidence-card','data' => ['evidence' => $evidence]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.show.evidences.evidence-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['evidence' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($evidence)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal805975d0e20b8350387489926caabc49)): ?>
<?php $attributes = $__attributesOriginal805975d0e20b8350387489926caabc49; ?>
<?php unset($__attributesOriginal805975d0e20b8350387489926caabc49); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal805975d0e20b8350387489926caabc49)): ?>
<?php $component = $__componentOriginal805975d0e20b8350387489926caabc49; ?>
<?php unset($__componentOriginal805975d0e20b8350387489926caabc49); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php else: ?>
            <!-- Estado vacío mejorado -->
            <div class="text-center py-12">
                <div class="inline-flex items-center justify-center w-20 h-20 bg-amber-100 rounded-full mb-4">
                    <i class="fas fa-images text-3xl text-amber-500"></i>
                </div>
                <h4 class="text-lg font-semibold text-gray-700 mb-2">No hay evidencias adjuntas</h4>
                <p class="text-gray-500 mb-6 max-w-md mx-auto">
                    Aún no se han agregado archivos a esta solicitud. Puedes comenzar subiendo la primera evidencia.
                </p>
                <div class="bg-amber-50 border border-amber-200 rounded-lg p-4 max-w-md mx-auto mb-6">
                    <div class="flex items-start">
                        <i class="fas fa-lightbulb text-amber-500 mt-1 mr-3"></i>
                        <div class="text-left">
                            <p class="text-sm font-medium text-amber-800">Sugerencia</p>
                            <p class="text-xs text-amber-700">Puedes subir imágenes, PDFs, documentos y otros archivos relacionados</p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Sección de subida de archivos -->
        <div class="<?php echo e($serviceRequest->evidences->count() > 0 ? 'mt-8 pt-6 border-t border-gray-200' : ''); ?>">
            <div class="bg-gray-50 rounded-xl p-4 border border-gray-200">
                <div class="flex items-center justify-between mb-4">
                    <div class="flex items-center">
                        <i class="fas fa-cloud-upload-alt text-gray-600 mr-2"></i>
                        <h4 class="text-md font-semibold text-gray-700">
                            <?php echo e($serviceRequest->evidences->count() > 0 ? 'Agregar más archivos' : 'Subir primera evidencia'); ?>

                        </h4>
                    </div>
                    <span class="text-xs text-gray-500 bg-white px-2 py-1 rounded border">
                        Máx. 10MB por archivo
                    </span>
                </div>
                <?php if (isset($component)) { $__componentOriginalcd359ec576c867d67b27e2dc80cf491b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd359ec576c867d67b27e2dc80cf491b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.show.evidences.evidence-uploader','data' => ['serviceRequest' => $serviceRequest]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.show.evidences.evidence-uploader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['serviceRequest' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($serviceRequest)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd359ec576c867d67b27e2dc80cf491b)): ?>
<?php $attributes = $__attributesOriginalcd359ec576c867d67b27e2dc80cf491b; ?>
<?php unset($__attributesOriginalcd359ec576c867d67b27e2dc80cf491b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd359ec576c867d67b27e2dc80cf491b)): ?>
<?php $component = $__componentOriginalcd359ec576c867d67b27e2dc80cf491b; ?>
<?php unset($__componentOriginalcd359ec576c867d67b27e2dc80cf491b); ?>
<?php endif; ?>
            </div>
        </div>

        <!-- Información adicional -->
        <?php if($serviceRequest->evidences->count() > 0): ?>
        <div class="mt-4 text-center">
            <p class="text-xs text-gray-500">
                <i class="fas fa-info-circle mr-1"></i>
                Todos los archivos están almacenados de forma segura y son accesibles para los usuarios autorizados
            </p>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\sdm\resources\views/components/service-requests/show/evidences/evidence-gallery.blade.php ENDPATH**/ ?>