<?php $__env->startSection('title', $service->name); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-6">
    <!-- Header -->
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-2xl font-bold text-gray-800"><?php echo e($service->name); ?></h1>
            <div class="flex items-center mt-2 space-x-4">
                <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium <?php echo e($service->is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                    <i class="fas fa-circle mr-1" style="font-size: 6px;"></i>
                    <?php echo e($service->is_active ? 'Activo' : 'Inactivo'); ?>

                </span>
                <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                    <i class="fas fa-hashtag mr-1"></i>
                    <?php echo e($service->code); ?>

                </span>
                <?php if($service->family): ?>
                <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-purple-100 text-purple-800">
                    <i class="fas fa-layer-group mr-1"></i>
                    <?php echo e($service->family->name); ?>

                </span>
                <?php endif; ?>
            </div>
        </div>
        <div class="flex space-x-2">
            <a href="<?php echo e(route('services.edit', $service)); ?>"
               class="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg flex items-center">
                <i class="fas fa-edit mr-2"></i>Editar
            </a>
            <a href="<?php echo e(route('services.index')); ?>"
               class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg flex items-center">
                <i class="fas fa-arrow-left mr-2"></i>Volver
            </a>
        </div>
    </div>

    <!-- Alertas -->
    <?php if(session('success')): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded">
            <div class="flex items-center">
                <i class="fas fa-check-circle mr-2"></i>
                <span><?php echo e(session('success')); ?></span>
            </div>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded">
            <div class="flex items-center">
                <i class="fas fa-exclamation-circle mr-2"></i>
                <span><?php echo e(session('error')); ?></span>
            </div>
        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Información del Servicio -->
        <div class="lg:col-span-2">
            <div class="bg-white shadow-md rounded-lg overflow-hidden">
                <div class="bg-blue-600 text-white px-6 py-4">
                    <h2 class="text-xl font-bold">Información del Servicio</h2>
                </div>
                <div class="p-6">
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Nombre</label>
                            <p class="text-gray-900"><?php echo e($service->name); ?></p>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Código</label>
                            <p class="text-gray-900 font-mono"><?php echo e($service->code); ?></p>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Familia</label>
                            <p class="text-gray-900">
                                <?php if($service->family): ?>
                                    <?php echo e($service->family->name); ?> (<?php echo e($service->family->code); ?>)
                                <?php else: ?>
                                    <span class="text-gray-400 italic">Sin familia asignada</span>
                                <?php endif; ?>
                            </p>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Descripción</label>
                            <p class="text-gray-900 whitespace-pre-line">
                                <?php echo e($service->description ?? 'Sin descripción'); ?>

                            </p>
                        </div>

                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Estado</label>
                                <p class="text-gray-900">
                                    <span class="inline-flex items-center px-2 py-1 rounded text-xs font-medium <?php echo e($service->is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                                        <?php echo e($service->is_active ? 'Activo' : 'Inactivo'); ?>

                                    </span>
                                </p>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Orden</label>
                                <p class="text-gray-900"><?php echo e($service->order); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sub-Servicios -->
        <div>
            <div class="bg-white shadow-md rounded-lg overflow-hidden">
                <div class="bg-green-600 text-white px-6 py-4">
                    <div class="flex justify-between items-center">
                        <h2 class="text-xl font-bold">Sub-Servicios</h2>
                        <span class="bg-green-700 text-white px-2 py-1 rounded-full text-sm">
                            <?php echo e($service->subServices->count()); ?>

                        </span>
                    </div>
                </div>
                <div class="p-6">
                    <?php if($service->subServices->count() > 0): ?>
                        <div class="space-y-3">
                            <?php $__currentLoopData = $service->subServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition duration-150">
                                <div class="flex justify-between items-start">
                                    <div>
                                        <h3 class="font-medium text-gray-900"><?php echo e($subService->name); ?></h3>
                                        <?php if($subService->description): ?>
                                        <p class="text-sm text-gray-500 mt-1"><?php echo e(Str::limit($subService->description, 80)); ?></p>
                                        <?php endif; ?>
                                    </div>
                                    <span class="inline-flex items-center px-2 py-1 rounded text-xs font-medium <?php echo e($subService->is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                                        <?php echo e($subService->is_active ? 'Activo' : 'Inactivo'); ?>

                                    </span>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-8">
                            <i class="fas fa-list-alt text-4xl text-gray-300 mb-3"></i>
                            <p class="text-gray-500">No hay sub-servicios registrados</p>
                            <p class="text-sm text-gray-400 mt-1">Los sub-servicios se mostrarán aquí</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Información Adicional -->
            <div class="bg-white shadow-md rounded-lg overflow-hidden mt-6">
                <div class="bg-gray-600 text-white px-6 py-4">
                    <h2 class="text-xl font-bold">Información Adicional</h2>
                </div>
                <div class="p-6">
                    <div class="space-y-3 text-sm">
                        <div class="flex justify-between">
                            <span class="text-gray-600">Creado:</span>
                            <span class="text-gray-900"><?php echo e($service->created_at->format('d/m/Y H:i')); ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Actualizado:</span>
                            <span class="text-gray-900"><?php echo e($service->updated_at->format('d/m/Y H:i')); ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">ID:</span>
                            <span class="text-gray-900 font-mono"><?php echo e($service->id); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sdm\resources\views/services/show.blade.php ENDPATH**/ ?>