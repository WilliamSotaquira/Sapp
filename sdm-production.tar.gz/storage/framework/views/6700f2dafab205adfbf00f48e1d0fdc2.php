<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['serviceRequest']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['serviceRequest']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="border-2 border-dashed border-gray-300 rounded-2xl p-6 text-center hover:border-gray-400 transition duration-150">
    <div class="max-w-md mx-auto">
        <i class="fas fa-cloud-upload-alt text-3xl text-gray-400 mb-4"></i>
        <h4 class="text-lg font-semibold text-gray-700 mb-2">Agregar Evidencias</h4>
        <p class="text-gray-500 text-sm mb-4">
            Arrastra y suelta archivos aquí o haz clic para seleccionarlos
        </p>

        <!-- Mensajes de éxito/error -->
        <?php if(session('success')): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                <i class="fas fa-check-circle mr-2"></i><?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <i class="fas fa-exclamation-triangle mr-2"></i><?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('service-requests.evidences.store', $serviceRequest)); ?>"
              method="POST"
              enctype="multipart/form-data"
              class="space-y-4"
              id="evidenceUploadForm">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="service_request_id" value="<?php echo e($serviceRequest->id); ?>">

            <div class="flex items-center justify-center">
                <label for="evidenceFiles" class="cursor-pointer">
                    <span class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition duration-150 inline-flex items-center font-semibold">
                        <i class="fas fa-plus mr-2"></i>Seleccionar Archivos
                    </span>
                    <input type="file"
                           name="files[]"
                           id="evidenceFiles"
                           multiple
                           class="hidden"
                           accept=".jpg,.jpeg,.png,.gif,.pdf,.doc,.docx,.xls,.xlsx,.txt,.zip,.rar"
                           onchange="handleFileSelection(this)">
                </label>
            </div>

            <div id="fileList" class="text-left space-y-2 hidden"></div>

            <div class="text-xs text-gray-400">
                Formatos permitidos: JPG, PNG, GIF, PDF, DOC, XLS, TXT, ZIP<br>
                Tamaño máximo por archivo: 10MB
            </div>

            <button type="submit"
                    id="uploadButton"
                    class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition duration-150 font-semibold hidden">
                <i class="fas fa-upload mr-2"></i>Subir Archivos
            </button>
        </form>
    </div>
</div>

<script>
function handleFileSelection(input) {
    const fileList = document.getElementById('fileList');
    const uploadButton = document.getElementById('uploadButton');

    if(input.files.length > 0) {
        fileList.innerHTML = '';
        fileList.classList.remove('hidden');
        uploadButton.classList.remove('hidden');

        Array.from(input.files).forEach(file => {
            const fileItem = document.createElement('div');
            fileItem.className = 'flex items-center justify-between p-2 bg-gray-50 rounded';
            fileItem.innerHTML = `
                <div class="flex items-center space-x-2">
                    <i class="fas fa-file text-gray-400"></i>
                    <span class="text-sm text-gray-700">${file.name}</span>
                </div>
                <span class="text-xs text-gray-500">${(file.size / 1024).toFixed(1)} KB</span>
            `;
            fileList.appendChild(fileItem);
        });
    } else {
        fileList.classList.add('hidden');
        uploadButton.classList.add('hidden');
    }
}

// Drag and drop functionality
const uploadArea = document.querySelector('.border-dashed');
if (uploadArea) {
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        uploadArea.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    ['dragenter', 'dragover'].forEach(eventName => {
        uploadArea.addEventListener(eventName, highlight, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        uploadArea.addEventListener(eventName, unhighlight, false);
    });

    function highlight() {
        uploadArea.classList.add('border-blue-400', 'bg-blue-50');
    }

    function unhighlight() {
        uploadArea.classList.remove('border-blue-400', 'bg-blue-50');
    }

    uploadArea.addEventListener('drop', handleDrop, false);

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        document.getElementById('evidenceFiles').files = files;
        handleFileSelection(document.getElementById('evidenceFiles'));
    }
}

// Limpiar formulario después de enviar
document.getElementById('evidenceUploadForm')?.addEventListener('submit', function() {
    setTimeout(() => {
        this.reset();
        document.getElementById('fileList').classList.add('hidden');
        document.getElementById('uploadButton').classList.add('hidden');
    }, 1000);
});
</script>
<?php /**PATH C:\xampp\htdocs\sdm\resources\views/components/service-requests/show/evidences/evidence-uploader.blade.php ENDPATH**/ ?>