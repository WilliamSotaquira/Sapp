<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['serviceRequest']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['serviceRequest']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>


<?php
    use App\Models\User;
    $technicians = User::orderBy('name')->get();
?>

<!-- Header Principal -->
<div class="bg-gradient-to-r from-blue-600 to-indigo-700 shadow-xl rounded-2xl overflow-hidden mb-8 d-flex w-full">
    <div class="px-8 py-6 text-white">
        <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between">
            <div class="flex items-center space-x-4 mb-4 lg:mb-0 md:items-stretch space-y-6 lg:space-y-0">
                <div class="bg-white/20 p-3 rounded-2xl backdrop-blur-sm flex items-center flex-col ">
                    <i class="fas fa-ticket-alt text-5xl"></i>
                    <span class="mt-2 inline-flex">
                        <?php if (isset($component)) { $__componentOriginal5e43ed0756d273feaa48297a51595f77 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5e43ed0756d273feaa48297a51595f77 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.show.header.criticality-indicator','data' => ['criticality' => $serviceRequest->criticality_level]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.show.header.criticality-indicator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['criticality' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($serviceRequest->criticality_level)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5e43ed0756d273feaa48297a51595f77)): ?>
<?php $attributes = $__attributesOriginal5e43ed0756d273feaa48297a51595f77; ?>
<?php unset($__attributesOriginal5e43ed0756d273feaa48297a51595f77); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5e43ed0756d273feaa48297a51595f77)): ?>
<?php $component = $__componentOriginal5e43ed0756d273feaa48297a51595f77; ?>
<?php unset($__componentOriginal5e43ed0756d273feaa48297a51595f77); ?>
<?php endif; ?>
                    </span>
                </div>
                <div class="flex flex-col max-w-lg">
                    <h1 class="text-2xl font-bold">Solicitud #<?php echo e($serviceRequest->ticket_number); ?></h1>
                    <span class="inline-flex">
                        <p class="text-blue-100 opacity-90 mt-1 text-sm"><?php echo e($serviceRequest->title); ?></p>
                    </span>

                </div>
            </div>

            <div class="flex flex-col lg:flex-row items-start lg:items-center space-y-3 lg:space-y-0 lg:space-x-3 max-w-md">

                <!-- Componente unificado de acciones -->
                <?php if (isset($component)) { $__componentOriginalc7bdd3f88a0ae82b10210aea32b3c783 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc7bdd3f88a0ae82b10210aea32b3c783 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.show.header.workflow-actions','data' => ['serviceRequest' => $serviceRequest,'technicians' => $technicians,'showLabels' => true,'compact' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.show.header.workflow-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['serviceRequest' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($serviceRequest),'technicians' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($technicians),'showLabels' => true,'compact' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc7bdd3f88a0ae82b10210aea32b3c783)): ?>
<?php $attributes = $__attributesOriginalc7bdd3f88a0ae82b10210aea32b3c783; ?>
<?php unset($__attributesOriginalc7bdd3f88a0ae82b10210aea32b3c783); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc7bdd3f88a0ae82b10210aea32b3c783)): ?>
<?php $component = $__componentOriginalc7bdd3f88a0ae82b10210aea32b3c783; ?>
<?php unset($__componentOriginalc7bdd3f88a0ae82b10210aea32b3c783); ?>
<?php endif; ?>

                <!-- SOLUCIÓN: Usar solo el componente status-indicator -->
                <?php if (isset($component)) { $__componentOriginal6dea49c1a7096db61d4df47455144e4a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6dea49c1a7096db61d4df47455144e4a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.show.header.status-indicator','data' => ['serviceRequest' => $serviceRequest]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.show.header.status-indicator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['serviceRequest' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($serviceRequest)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6dea49c1a7096db61d4df47455144e4a)): ?>
<?php $attributes = $__attributesOriginal6dea49c1a7096db61d4df47455144e4a; ?>
<?php unset($__attributesOriginal6dea49c1a7096db61d4df47455144e4a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6dea49c1a7096db61d4df47455144e4a)): ?>
<?php $component = $__componentOriginal6dea49c1a7096db61d4df47455144e4a; ?>
<?php unset($__componentOriginal6dea49c1a7096db61d4df47455144e4a); ?>
<?php endif; ?>

            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\sdm\resources\views/components/service-requests/show/header/main-header.blade.php ENDPATH**/ ?>