<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Session Status -->
    <?php if (isset($component)) { $__componentOriginal151c4c1aa789e40d0ad06afc137ad3f0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal151c4c1aa789e40d0ad06afc137ad3f0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.core.feedback.auth-session-status','data' => ['class' => 'mb-4','status' => session('status')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('core.feedback.auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal151c4c1aa789e40d0ad06afc137ad3f0)): ?>
<?php $attributes = $__attributesOriginal151c4c1aa789e40d0ad06afc137ad3f0; ?>
<?php unset($__attributesOriginal151c4c1aa789e40d0ad06afc137ad3f0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal151c4c1aa789e40d0ad06afc137ad3f0)): ?>
<?php $component = $__componentOriginal151c4c1aa789e40d0ad06afc137ad3f0; ?>
<?php unset($__componentOriginal151c4c1aa789e40d0ad06afc137ad3f0); ?>
<?php endif; ?>

    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>

        <!-- Email Address -->
        <div>
            <?php if (isset($component)) { $__componentOriginal296b8cd6af83e5624391e74dea8833ab = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal296b8cd6af83e5624391e74dea8833ab = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.forms.input-label','data' => ['for' => 'email','value' => __('Email')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.forms.input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'email','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Email'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal296b8cd6af83e5624391e74dea8833ab)): ?>
<?php $attributes = $__attributesOriginal296b8cd6af83e5624391e74dea8833ab; ?>
<?php unset($__attributesOriginal296b8cd6af83e5624391e74dea8833ab); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal296b8cd6af83e5624391e74dea8833ab)): ?>
<?php $component = $__componentOriginal296b8cd6af83e5624391e74dea8833ab; ?>
<?php unset($__componentOriginal296b8cd6af83e5624391e74dea8833ab); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalff3371853c13d3ba01bff6d87d8ecff2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff3371853c13d3ba01bff6d87d8ecff2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.forms.text-input','data' => ['id' => 'email','class' => 'block mt-1 w-full','type' => 'email','name' => 'email','value' => old('email'),'required' => true,'autofocus' => true,'autocomplete' => 'username']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.forms.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'email','class' => 'block mt-1 w-full','type' => 'email','name' => 'email','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('email')),'required' => true,'autofocus' => true,'autocomplete' => 'username']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff3371853c13d3ba01bff6d87d8ecff2)): ?>
<?php $attributes = $__attributesOriginalff3371853c13d3ba01bff6d87d8ecff2; ?>
<?php unset($__attributesOriginalff3371853c13d3ba01bff6d87d8ecff2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff3371853c13d3ba01bff6d87d8ecff2)): ?>
<?php $component = $__componentOriginalff3371853c13d3ba01bff6d87d8ecff2; ?>
<?php unset($__componentOriginalff3371853c13d3ba01bff6d87d8ecff2); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalad6e120586abfa0dc479588fa10434b3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad6e120586abfa0dc479588fa10434b3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.forms.input-error','data' => ['messages' => $errors->get('email'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.forms.input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('email')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad6e120586abfa0dc479588fa10434b3)): ?>
<?php $attributes = $__attributesOriginalad6e120586abfa0dc479588fa10434b3; ?>
<?php unset($__attributesOriginalad6e120586abfa0dc479588fa10434b3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad6e120586abfa0dc479588fa10434b3)): ?>
<?php $component = $__componentOriginalad6e120586abfa0dc479588fa10434b3; ?>
<?php unset($__componentOriginalad6e120586abfa0dc479588fa10434b3); ?>
<?php endif; ?>
        </div>

        <!-- Password -->
        <div class="mt-4">
            <?php if (isset($component)) { $__componentOriginal296b8cd6af83e5624391e74dea8833ab = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal296b8cd6af83e5624391e74dea8833ab = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.forms.input-label','data' => ['for' => 'password','value' => __('Password')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.forms.input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'password','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Password'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal296b8cd6af83e5624391e74dea8833ab)): ?>
<?php $attributes = $__attributesOriginal296b8cd6af83e5624391e74dea8833ab; ?>
<?php unset($__attributesOriginal296b8cd6af83e5624391e74dea8833ab); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal296b8cd6af83e5624391e74dea8833ab)): ?>
<?php $component = $__componentOriginal296b8cd6af83e5624391e74dea8833ab; ?>
<?php unset($__componentOriginal296b8cd6af83e5624391e74dea8833ab); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalff3371853c13d3ba01bff6d87d8ecff2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff3371853c13d3ba01bff6d87d8ecff2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.forms.text-input','data' => ['id' => 'password','class' => 'block mt-1 w-full','type' => 'password','name' => 'password','required' => true,'autocomplete' => 'current-password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.forms.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'password','class' => 'block mt-1 w-full','type' => 'password','name' => 'password','required' => true,'autocomplete' => 'current-password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff3371853c13d3ba01bff6d87d8ecff2)): ?>
<?php $attributes = $__attributesOriginalff3371853c13d3ba01bff6d87d8ecff2; ?>
<?php unset($__attributesOriginalff3371853c13d3ba01bff6d87d8ecff2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff3371853c13d3ba01bff6d87d8ecff2)): ?>
<?php $component = $__componentOriginalff3371853c13d3ba01bff6d87d8ecff2; ?>
<?php unset($__componentOriginalff3371853c13d3ba01bff6d87d8ecff2); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalad6e120586abfa0dc479588fa10434b3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad6e120586abfa0dc479588fa10434b3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.forms.input-error','data' => ['messages' => $errors->get('password'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.forms.input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('password')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad6e120586abfa0dc479588fa10434b3)): ?>
<?php $attributes = $__attributesOriginalad6e120586abfa0dc479588fa10434b3; ?>
<?php unset($__attributesOriginalad6e120586abfa0dc479588fa10434b3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad6e120586abfa0dc479588fa10434b3)): ?>
<?php $component = $__componentOriginalad6e120586abfa0dc479588fa10434b3; ?>
<?php unset($__componentOriginalad6e120586abfa0dc479588fa10434b3); ?>
<?php endif; ?>
        </div>

        <!-- Remember Me -->
        <div class="block mt-4">
            <label for="remember_me" class="inline-flex items-center">
                <input id="remember_me" type="checkbox" class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500" name="remember">
                <span class="ms-2 text-sm text-gray-600"><?php echo e(__('Remember me')); ?></span>
            </label>
        </div>

        <div class="flex items-center justify-end mt-4">
            <?php if(Route::has('password.request')): ?>
                <a class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500" href="<?php echo e(route('password.request')); ?>">
                    <?php echo e(__('Forgot your password?')); ?>

                </a>
            <?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal58bb7652f8a9b71c66ccd46a9fafa18a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal58bb7652f8a9b71c66ccd46a9fafa18a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.buttons.primary-button','data' => ['class' => 'ms-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.buttons.primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'ms-3']); ?>
                <?php echo e(__('Log in')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal58bb7652f8a9b71c66ccd46a9fafa18a)): ?>
<?php $attributes = $__attributesOriginal58bb7652f8a9b71c66ccd46a9fafa18a; ?>
<?php unset($__attributesOriginal58bb7652f8a9b71c66ccd46a9fafa18a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal58bb7652f8a9b71c66ccd46a9fafa18a)): ?>
<?php $component = $__componentOriginal58bb7652f8a9b71c66ccd46a9fafa18a; ?>
<?php unset($__componentOriginal58bb7652f8a9b71c66ccd46a9fafa18a); ?>
<?php endif; ?>
        </div>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\sdm\resources\views/auth/login.blade.php ENDPATH**/ ?>