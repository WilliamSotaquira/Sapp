<?php $__env->startSection('title', "Timeline - {$request->ticket_number}"); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white shadow rounded-lg">
    <!-- Header -->
    <div class="bg-blue-600 text-white px-6 py-4 rounded-t-lg">
        <div class="flex justify-between items-center">
            <div class="flex items-center space-x-3">
                <i class="fas fa-history text-xl"></i>
                <h1 class="text-xl font-bold">Línea de Tiempo - <?php echo e($request->ticket_number); ?></h1>
            </div>
            <div class="flex space-x-2">
                <a href="<?php echo e(route('reports.timeline.export', [$request->id, 'pdf'])); ?>"
                    class="bg-white text-blue-600 hover:bg-blue-50 px-4 py-2 rounded-lg font-medium transition-colors">
                    <i class="fas fa-file-pdf mr-2"></i>PDF
                </a>
                <a href="<?php echo e(route('reports.timeline.export', [$request->id, 'excel'])); ?>"
                    class="bg-white text-blue-600 hover:bg-blue-50 px-4 py-2 rounded-lg font-medium transition-colors">
                    <i class="fas fa-file-excel mr-2"></i>Excel
                </a>
            </div>
        </div>
    </div>

    <div class="p-6">
        <!-- Información de la solicitud -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <!-- Información principal -->
            <div class="bg-gray-50 rounded-lg border border-gray-200">
                <div class="bg-gray-100 px-4 py-3 border-b border-gray-200">
                    <h2 class="text-lg font-semibold text-gray-800">
                        <i class="fas fa-info-circle mr-2 text-blue-500"></i>Información de la Solicitud
                    </h2>
                </div>
                <div class="p-4">
                    <div class="space-y-3">
                        <div class="flex justify-between items-center">
                            <span class="text-gray-600 font-medium">Ticket #:</span>
                            <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                                <?php echo e($request->ticket_number); ?>

                            </span>
                        </div>
                        <div class="flex justify-between items-start">
                            <span class="text-gray-600 font-medium">Título:</span>
                            <span class="text-gray-900 font-semibold text-right"><?php echo e($request->title); ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-600 font-medium">Estado:</span>
                            <?php
                            $statusColors = [
                            'PENDIENTE' => 'bg-yellow-100 text-yellow-800',
                            'ASIGNADA' => 'bg-blue-100 text-blue-800',
                            'EN_PROCESO' => 'bg-purple-100 text-purple-800',
                            'PAUSADA' => 'bg-gray-100 text-gray-800',
                            'RESUELTA' => 'bg-green-100 text-green-800',
                            'CERRADA' => 'bg-gray-200 text-gray-800',
                            'CANCELADA' => 'bg-red-100 text-red-800'
                            ];
                            $statusColor = $statusColors[$request->status] ?? 'bg-gray-100 text-gray-800';
                            ?>
                            <span class="<?php echo e($statusColor); ?> px-3 py-1 rounded-full text-sm font-medium">
                                <i class="fas fa-<?php echo e(getStatusIcon($request->status)); ?> mr-1"></i>
                                <?php echo e($request->status); ?>

                            </span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-600 font-medium">Prioridad:</span>
                            <?php
                            $priorityColors = [
                            'BAJA' => 'bg-green-100 text-green-800',
                            'MEDIA' => 'bg-yellow-100 text-yellow-800',
                            'ALTA' => 'bg-orange-100 text-orange-800',
                            'CRITICA' => 'bg-red-100 text-red-800'
                            ];
                            $priorityColor = $priorityColors[$request->criticality_level] ?? 'bg-gray-100 text-gray-800';
                            ?>
                            <span class="<?php echo e($priorityColor); ?> px-3 py-1 rounded-full text-sm font-medium">
                                <i class="fas fa-<?php echo e($request->criticality_level == 'ALTA' ? 'exclamation-triangle' : 'flag'); ?> mr-1"></i>
                                <?php echo e($request->criticality_level); ?>

                            </span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-600 font-medium">Fecha Creación:</span>
                            <div class="text-right">
                                <div class="text-gray-900"><?php echo e($request->created_at->format('d/m/Y H:i')); ?></div>
                                <div class="text-gray-500 text-sm"><?php echo e($request->created_at->diffForHumans()); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Asignaciones -->
            <div class="bg-gray-50 rounded-lg border border-gray-200">
                <div class="bg-gray-100 px-4 py-3 border-b border-gray-200">
                    <h2 class="text-lg font-semibold text-gray-800">
                        <i class="fas fa-users mr-2 text-blue-500"></i>Asignaciones
                    </h2>
                </div>
                <div class="p-4">
                    <div class="space-y-3">
                        <div class="flex justify-between items-center">
                            <span class="text-gray-600 font-medium">Solicitante:</span>
                            <div class="flex items-center space-x-2">
                                <div class="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                                    <i class="fas fa-user text-blue-600 text-sm"></i>
                                </div>
                                <span class="text-gray-900"><?php echo e($request->requester->name ?? 'N/A'); ?></span>
                            </div>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-600 font-medium">Asignado a:</span>
                            <?php if($request->assignee): ?>
                            <div class="flex items-center space-x-2">
                                <div class="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                                    <i class="fas fa-user-tie text-green-600 text-sm"></i>
                                </div>
                                <span class="text-gray-900"><?php echo e($request->assignee->name); ?></span>
                            </div>
                            <?php else: ?>
                            <span class="text-gray-500 italic">No asignado</span>
                            <?php endif; ?>
                        </div>
                        <div class="flex justify-between items-start">
                            <span class="text-gray-600 font-medium">Sub-Servicio:</span>
                            <div class="text-right">
                                <div class="text-gray-900"><?php echo e($request->subService->name ?? 'N/A'); ?></div>
                                <?php if($request->subService && $request->subService->service): ?>
                                <div class="text-gray-500 text-sm">
                                    <?php echo e($request->subService->service->name ?? ''); ?>

                                    <?php if($request->subService->service->family): ?>
                                    - <?php echo e($request->subService->service->family->name ?? ''); ?>

                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="flex justify-between items-start">
                            <span class="text-gray-600 font-medium">SLA:</span>
                            <div class="text-right">
                                <div class="text-gray-900"><?php echo e($request->sla->name ?? 'N/A'); ?></div>
                                <?php if($request->sla): ?>
                                <div class="text-gray-500 text-sm">
                                    <?php echo e($request->sla->criticality_level); ?> -
                                    Resolución: <?php echo e($request->sla->resolution_time_minutes); ?> min
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Estadísticas de Tiempo -->
        <div class="bg-white rounded-lg shadow p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Estadísticas de Tiempo</h3>

            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div class="border-r border-gray-200 last:border-r-0">
                    <div class="text-gray-600 text-sm mb-1">Tiempo Total</div>
                    <div class="text-2xl font-bold text-blue-600">
                        <?php echo e(is_numeric($totalResolutionTime) ? $totalResolutionTime . ' min' : $totalResolutionTime); ?>

                    </div>
                </div>

                <div class="border-r border-gray-200 last:border-r-0">
                    <div class="text-gray-600 text-sm mb-1">Tiempo Activo</div>
                    <div class="text-2xl font-bold text-green-600">
                        <?php
                        $activeTime = 0;
                        if (!empty($timeInStatus)) {
                        foreach ($timeInStatus as $status => $minutes) {
                        if (!in_array($status, ['PAUSADA'])) {
                        $activeTime += $minutes;
                        }
                        }
                        }
                        ?>
                        <?php echo e($activeTime); ?> min
                    </div>
                </div>

                <div class="border-r border-gray-200 last:border-r-0">
                    <div class="text-gray-600 text-sm mb-1">Estados</div>
                    <div class="text-2xl font-bold text-purple-600">
                        <?php echo e(count($timeInStatus)); ?>

                    </div>
                </div>

                <div>
                    <div class="text-gray-600 text-sm mb-1">Eventos</div>
                    <div class="text-2xl font-bold text-orange-600">
                        <?php echo e(count($timelineEvents)); ?>

                    </div>
                </div>
            </div>
        </div>

        <!-- Tiempo por Estado -->
        <?php if(!empty($timeStatistics) && is_array($timeStatistics)): ?>
        <div class="bg-white rounded-lg shadow p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Tiempo por Estado</h3>

            <div class="space-y-3">
                <?php $__currentLoopData = $timeStatistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(is_array($data) && isset($data['formatted_time'])): ?>
                <div class="flex justify-between items-center">
                    <span class="text-gray-700"><?php echo e($status); ?></span>
                    <div class="text-right">
                        <span class="font-semibold"><?php echo e($data['formatted_time']); ?></span>
                        <span class="text-sm text-gray-500 ml-2">(<?php echo e($data['percentage'] ?? '0'); ?>%)</span>
                    </div>
                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Resumen por Tipo de Evento -->
        <div class="bg-white rounded-lg shadow p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Resumen por Tipo de Evento</h3>

            <?php if(!empty($timeSummary) && is_array($timeSummary)): ?>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="bg-gray-50">
                            <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Tipo de Evento</th>
                            <th class="px-4 py-3 text-center text-sm font-semibold text-gray-700">Cantidad</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Último Evento</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php $__currentLoopData = $timeSummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventType => $summary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-4 py-3">
                                <div class="flex items-center space-x-2">
                                    <?php
                                    $iconMap = [
                                    'created' => 'plus-circle',
                                    'assigned' => 'user-check',
                                    'accepted' => 'check-circle',
                                    'responded' => 'reply',
                                    'paused' => 'pause-circle',
                                    'resumed' => 'play-circle',
                                    'resolved' => 'check-double',
                                    'closed' => 'lock',
                                    'evidence' => 'file-alt',
                                    'web_route' => 'link',
                                    'main_route' => 'star',
                                    'breach' => 'exclamation-triangle'
                                    ];
                                    $icon = $iconMap[$eventType] ?? 'circle';
                                    ?>
                                    <i class="fas fa-<?php echo e($icon); ?> text-gray-400"></i>
                                    <span class="text-gray-700"><?php echo e(ucfirst(str_replace('_', ' ', $eventType))); ?></span>
                                </div>
                            </td>
                            <td class="px-4 py-3 text-center font-semibold text-gray-900">
                                <?php echo e($summary['count'] ?? 0); ?>

                            </td>
                            <td class="px-4 py-3 text-gray-600">
                                <?php echo e($summary['last_time'] ? $summary['last_time']->format('d/m/Y H:i') : 'N/A'); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center text-gray-500 py-8">
                <i class="fas fa-chart-bar text-4xl mb-4"></i>
                <p>No hay datos de resumen disponibles</p>
            </div>
            <?php endif; ?>
        </div>

        <!-- Línea de Tiempo -->
        <div class="bg-white rounded-lg border border-gray-200">
            <div class="bg-gray-100 px-4 py-3 border-b border-gray-200">
                <h2 class="text-lg font-semibold text-gray-800">
                    <i class="fas fa-stream mr-2 text-blue-500"></i>Línea de Tiempo de Eventos
                    <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-sm font-medium ml-2">
                        <?php echo e(count($timelineEvents)); ?> eventos
                    </span>
                </h2>
            </div>
            <div class="p-6">
                <div class="relative">
                    <!-- Línea central -->
                    <div class="absolute left-1/2 transform -translate-x-1/2 w-0.5 bg-gray-300 h-full"></div>

                    <!-- Eventos -->
                    <div class="space-y-8">
                        <?php $__currentLoopData = $timelineEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="relative flex items-start <?php echo e($index % 2 == 0 ? 'justify-start' : 'justify-end'); ?>">
                            <!-- Contenido del evento -->
                            <div class="<?php echo e($index % 2 == 0 ? 'mr-8' : 'ml-8'); ?> w-5/12">
                                <div class="bg-white border border-gray-200 rounded-lg shadow-sm p-4 hover:shadow-md transition-shadow">
                                    <!-- Header -->
                                    <div class="flex justify-between items-start mb-3">
                                        <div class="flex-1">
                                            <h3 class="font-semibold text-gray-900 mb-1"><?php echo e($event['event']); ?></h3>
                                            <div class="flex items-center text-sm text-gray-500">
                                                <i class="fas fa-clock mr-1"></i>
                                                <?php echo e($event['timestamp']->format('d/m/Y H:i:s')); ?>

                                                <span class="mx-2">•</span>
                                                <?php echo e($event['timestamp']->diffForHumans()); ?>

                                            </div>
                                        </div>
                                        <?php if(isset($timeInStatus[$event['status']])): ?>
                                        <div class="bg-gray-100 text-gray-700 px-2 py-1 rounded text-sm">
                                            <i class="fas fa-hourglass-half mr-1"></i>
                                            <?php echo e($timeInStatus[$event['status']]['formatted']); ?>

                                        </div>
                                        <?php endif; ?>
                                    </div>

                                    <!-- Body -->
                                    <div class="text-gray-700 mb-3"><?php echo e($event['description']); ?></div>

                                    <!-- Footer -->
                                    <div class="flex justify-between items-center">
                                        <?php if($event['user']): ?>
                                        <div class="flex items-center space-x-2">
                                            <div class="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center">
                                                <i class="fas fa-user text-blue-600 text-xs"></i>
                                            </div>
                                            <span class="text-sm text-gray-600"><?php echo e($event['user']->name); ?></span>
                                        </div>
                                        <?php endif; ?>

                                        <?php if(isset($event['evidence_type'])): ?>
                                        <span class="bg-gray-100 text-gray-700 px-2 py-1 rounded text-sm">
                                            <i class="fas fa-<?php echo e(getEvidenceTypeIcon($event['evidence_type'])); ?> mr-1"></i>
                                            <?php echo e(getEvidenceTypeLabel($event['evidence_type'])); ?>

                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <!-- Marcador -->
                            <div class="absolute left-1/2 transform -translate-x-1/2 w-4 h-4 rounded-full border-4 border-white
                                bg-<?php echo e($event['color'] ?? 'gray'); ?>-500 shadow-lg z-10"></div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <div class="mt-6 flex flex-col sm:flex-row justify-between items-center space-y-4 sm:space-y-0">
            <div class="flex space-x-3">
                <a href="<?php echo e(route('reports.timeline.index')); ?>"
                    class="bg-gray-600 text-white hover:bg-gray-700 px-4 py-2 rounded-lg font-medium transition-colors">
                    <i class="fas fa-arrow-left mr-2"></i>Volver al Listado
                </a>
                <a href="<?php echo e(route('service-requests.show', $request->id)); ?>"
                    class="bg-blue-600 text-white hover:bg-blue-700 px-4 py-2 rounded-lg font-medium transition-colors">
                    <i class="fas fa-eye mr-2"></i>Ver Detalles de Solicitud
                </a>
            </div>
            <div class="text-sm text-gray-500">
                <i class="fas fa-sync-alt mr-1"></i>
                Actualizado: <?php echo e(now()->format('d/m/Y H:i')); ?>

            </div>
        </div>
    </div>
</div>

<?php
function getStatusIcon($status) {
$icons = [
'PENDIENTE' => 'clock',
'ACEPTADA' => 'check-circle',
'EN_PROCESO' => 'cogs',
'PAUSADA' => 'pause-circle',
'RESUELTA' => 'check-double',
'CERRADA' => 'lock',
'CANCELADA' => 'times-circle'
];
return $icons[$status] ?? 'question-circle';
}

function getEventTypeIcon($eventType) {
$icons = [
'Creación' => 'plus-circle',
'Asignación' => 'user-check',
'Aceptación' => 'check-circle',
'Respuesta Inicial' => 'reply',
'Pausa' => 'pause-circle',
'Reanudación' => 'play-circle',
'Resolución' => 'check-double',
'Cierre' => 'lock',
'Evidencia' => 'file-alt',
'Incumplimiento SLA' => 'exclamation-triangle'
];
return $icons[$eventType] ?? 'circle';
}

function getEvidenceTypeIcon($evidenceType) {
$icons = [
'PASO_A_PASO' => 'list-ol',
'ARCHIVO' => 'paperclip',
'COMENTARIO' => 'comment',
'SISTEMA' => 'cog'
];
return $icons[$evidenceType] ?? 'file-alt';
}

function getEvidenceTypeLabel($evidenceType) {
$labels = [
'PASO_A_PASO' => 'Paso a Paso',
'ARCHIVO' => 'Archivo',
'COMENTARIO' => 'Comentario',
'SISTEMA' => 'Sistema'
];
return $labels[$evidenceType] ?? $evidenceType;
}

function getEvidenceTypeColor($evidenceType) {
$colors = [
'PASO_A_PASO' => 'primary',
'ARCHIVO' => 'info',
'COMENTARIO' => 'secondary',
'SISTEMA' => 'dark'
];
return $colors[$evidenceType] ?? 'secondary';
}
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sdm\resources\views/reports/timeline-detail.blade.php ENDPATH**/ ?>