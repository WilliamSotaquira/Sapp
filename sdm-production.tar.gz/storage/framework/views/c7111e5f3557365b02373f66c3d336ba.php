<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['serviceRequest']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['serviceRequest']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if(in_array($serviceRequest->status, ['ACEPTADA', 'EN_PROCESO', 'RESUELTA', 'PAUSADA'])): ?>
    <?php
        $statusInfo = [
            'ACEPTADA' => [
                'icon' => 'user-check',
                'text' => $serviceRequest->accepted_at ? 'Aceptada el ' . $serviceRequest->accepted_at->format('d/m/Y H:i') : 'Aceptada'
            ],
            'EN_PROCESO' => [
                'icon' => 'cog',
                'text' => $serviceRequest->started_at ? 'En proceso desde ' . $serviceRequest->started_at->format('d/m/Y H:i') : 'En proceso'
            ],
            'RESUELTA' => [
                'icon' => 'check-double',
                'text' => $serviceRequest->resolved_at ? 'Resuelta el ' . $serviceRequest->resolved_at->format('d/m/Y H:i') : 'Resuelta'
            ],
            'PAUSADA' => [
                'icon' => 'pause',
                'text' => $serviceRequest->paused_at ? 'Pausada desde ' . $serviceRequest->paused_at->format('d/m/Y H:i') : 'Pausada'
            ]
        ][$serviceRequest->status];
    ?>

    <div class="bg-white/20 backdrop-blur-sm px-4 py-2 border-2 rounded-full text-sm font-semibold flex items-center border border-white/30 leading-tight">
        <i class="fas fa-<?php echo e($statusInfo['icon']); ?> mr-2"></i>
        <span><?php echo e($statusInfo['text']); ?></span>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sdm\resources\views/components/service-requests/show/header/status-indicator.blade.php ENDPATH**/ ?>