<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['priority', 'compact' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['priority', 'compact' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $priorityConfig = [
        'BAJA' => [
            'class' => 'bg-green-100 text-green-800',
            'icon' => 'fa-flag'
        ],
        'MEDIA' => [
            'class' => 'bg-yellow-100 text-yellow-800',
            'icon' => 'fa-flag'
        ],
        'ALTA' => [
            'class' => 'bg-orange-100 text-orange-800',
            'icon' => 'fa-exclamation-triangle'
        ],
        'CRITICA' => [
            'class' => 'bg-red-100 text-red-800',
            'icon' => 'fa-skull-crossbones'
        ]
    ];

    $config = $priorityConfig[$priority] ?? $priorityConfig['BAJA'];
    $sizeClass = $compact ? 'px-2 py-1 text-xs' : 'px-3 py-1 text-sm';
?>

<span class="<?php echo e($sizeClass); ?> font-medium rounded-full <?php echo e($config['class']); ?>">
    <i class="fas <?php echo e($config['icon']); ?> mr-1 text-xs"></i>
    <?php echo e($priority); ?>

</span>
<?php /**PATH C:\xampp\htdocs\sdm\resources\views/components/service-requests/index/content/priority-badge.blade.php ENDPATH**/ ?>