<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'serviceRequest',
    'showLabels' => true,
    'compact' => false,
    'disabled' => false,
    'technicians' => collect(),
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'serviceRequest',
    'showLabels' => true,
    'compact' => false,
    'disabled' => false,
    'technicians' => collect(),
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $workflowConfig = [
        'PENDIENTE' => [
            // Botón provisional para crear el nuevo servicio
            [
                'action' => 'create-service',
                'route' => 'service-requests.create',
                'color' => 'green',
                'icon' => 'plus-circle',
                'method' => 'GET',
                'label' => 'Crear Nuevo Servicio',
                'condition' => true,
            ],
            [
                'action' => $serviceRequest->assigned_to ? 'accept' : 'assign-technician',
                'route' => $serviceRequest->assigned_to ? 'accept-modal' : 'assign-technician-modal', // Cambiar a modal
                'color' => $serviceRequest->assigned_to ? 'emerald' : 'blue',
                'icon' => $serviceRequest->assigned_to ? 'handshake' : 'user-plus',
                'method' => $serviceRequest->assigned_to ? 'MODAL' : 'MODAL', // Ambos usan modal
                'label' => $serviceRequest->assigned_to ? 'Aceptar Solicitud' : 'Asignar Técnico Primero',
                'condition' => true,
                'modal_id' => $serviceRequest->assigned_to
                    ? 'accept-modal-' . $serviceRequest->id
                    : 'assign-technician-modal-' . $serviceRequest->id,
            ],
            [
                'action' => 'reject',
                'route' => 'reject-modal', // Cambiar a modal
                'color' => 'red',
                'icon' => 'times-circle',
                'method' => 'MODAL', // Cambiar a MODAL
                'label' => 'Rechazar Solicitud',
                'condition' => true,
                'modal_id' => 'reject-modal-' . $serviceRequest->id, // Agregar modal_id
            ],
        ],
        'ACEPTADA' => [
            [
                'action' => 'start',
                'route' => 'start-modal', // Cambiar a modal
                'color' => 'cyan',
                'icon' => 'play',
                'method' => 'MODAL', // Cambiar a MODAL
                'label' => 'Iniciar Servicio',
                'condition' => !empty($serviceRequest->assigned_to) && $serviceRequest->assigned_to > 0,
                'modal_id' => 'start-modal-' . $serviceRequest->id, // Agregar modal_id
            ],
            [
                'action' => 'reassign',
                'route' => 'service-requests.reassign',
                'color' => 'blue',
                'icon' => 'user-cog',
                'method' => 'GET',
                'label' => 'Reasignar Técnico',
                'condition' => true,
            ],
        ],
        'EN_PROCESO' => [
            [
                'action' => 'resolve',
                'route' => 'resolve-modal',
                'color' => 'green',
                'icon' => 'check-circle',
                'method' => 'MODAL',
                'label' => 'Resolver Solicitud',
                'condition' => $serviceRequest->evidences->where('evidence_type', 'ARCHIVO')->count() > 0,
                'modal_id' => 'resolve-modal-' . $serviceRequest->id,
            ],
            [
                'action' => 'pause',
                'route' => 'pause-modal',
                'color' => 'yellow',
                'icon' => 'pause',
                'method' => 'MODAL',
                'label' => 'Pausar Trabajo',
                'condition' => true,
                'modal_id' => 'pause-modal-' . $serviceRequest->id,
            ],
        ],
        'PAUSADA' => [
            [
                'action' => 'resume',
                'route' => 'resume-modal', // Cambiar a modal
                'color' => 'cyan',
                'icon' => 'play',
                'method' => 'MODAL', // Cambiar a MODAL
                'label' => 'Reanudar Trabajo',
                'condition' => true,
                'modal_id' => 'resume-modal-' . $serviceRequest->id,
            ],
            [
                'action' => 'close-vencimiento',
                'route' => 'vencimiento-modal',
                'color' => 'red',
                'icon' => 'clock',
                'method' => 'MODAL',
                'label' => 'Cerrar por Vencimiento',
                'condition' => true,
                'modal_id' => 'vencimiento-modal-' . $serviceRequest->id,
            ],
        ],
        'RESUELTA' => [
            [
                'action' => 'close',
                'route' => 'close-modal', // Cambiar a modal
                'color' => 'purple',
                'icon' => 'lock',
                'method' => 'MODAL', // Cambiar a MODAL
                'label' => 'Cerrar Solicitud',
                'condition' => true,
                'modal_id' => 'close-modal-' . $serviceRequest->id,
            ],
            [
                'action' => 'reopen',
                'route' => 'reopen-modal', // Cambiar a modal
                'color' => 'orange',
                'icon' => 'undo',
                'method' => 'MODAL', // Cambiar a MODAL
                'label' => 'Reabrir Solicitud',
                'condition' => true,
                'modal_id' => 'reopen-modal-' . $serviceRequest->id,
            ],
        ],
        'CERRADA' => [
            [
                'action' => 'download-pdf',
                'route' => 'service-requests.download-report',
                'color' => 'blue',
                'icon' => 'download',
                'method' => 'GET',
                'label' => 'Descargar PDF',
                'condition' => true,
            ],
        ],
    ];

    $currentStatus = $serviceRequest->status;
    $actions = $workflowConfig[$currentStatus] ?? [];
?>

<?php if(count($actions) > 0 && !$disabled): ?>
    <div class="<?php echo e($compact ? 'flex flex-col gap-2' : 'grid gap-3 md:grid-cols-3'); ?>">
        <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actionItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($actionItem['condition']): ?>
                <div
                    class="<?php echo e($compact ? '' : 'rounded-full border-2 border border-slate-300 shadow-sm'); ?> max-w-44 max-h-max">
                    
                    <?php if($actionItem['method'] === 'MODAL'): ?>
                        <button type="button"
                            onclick="document.getElementById('<?php echo e($actionItem['modal_id']); ?>').classList.remove('hidden')"
                            class="inline-flex items-center justify-center w-full px-6 py-2 bg-<?php echo e($actionItem['color']); ?>-600 border border-transparent text-sm rounded-full border-2 font-semibold text-white hover:bg-<?php echo e($actionItem['color']); ?>-700 active:bg-<?php echo e($actionItem['color']); ?>-800 focus:outline-none focus:ring-2 focus:ring-<?php echo e($actionItem['color']); ?>-500 focus:ring-offset-2 transition ease-in-out duration-150 <?php echo e($compact ? 'text-sm' : ''); ?> leading-4 text-start gap-1 max-h-14 max-w-44">
                            <i class="fas fa-<?php echo e($actionItem['icon']); ?> <?php echo e($showLabels ? 'mr-2' : ''); ?>"></i>
                            <?php if($showLabels): ?>
                                <?php echo e($actionItem['label']); ?>

                            <?php endif; ?>
                        </button>

                        
                    <?php elseif($actionItem['method'] === 'GET'): ?>
                        <a href="<?php echo e(route($actionItem['route'], $serviceRequest)); ?>"
                            class="inline-flex items-center justify-center w-full px-6 py-2 bg-<?php echo e($actionItem['color']); ?>-600 border border-transparent text-sm rounded-full border-2 font-semibold text-white hover:bg-<?php echo e($actionItem['color']); ?>-700 active:bg-<?php echo e($actionItem['color']); ?>-800 focus:outline-none focus:ring-2 focus:ring-<?php echo e($actionItem['color']); ?>-500 focus:ring-offset-2 transition ease-in-out duration-150 no-underline <?php echo e($compact ? 'text-sm' : ''); ?> leading-4 text-start gap-1 max-h-14 max-w-44">
                            <i class="fas fa-<?php echo e($actionItem['icon']); ?> <?php echo e($showLabels ? 'mr-2' : ''); ?>"></i>
                            <?php if($showLabels): ?>
                                <?php echo e($actionItem['label']); ?>

                            <?php endif; ?>
                        </a>

                        
                    <?php else: ?>
                        <form action="<?php echo e(route($actionItem['route'], $serviceRequest)); ?>" method="POST"
                            class="inline w-full">
                            <?php echo csrf_field(); ?>
                            <?php if($actionItem['method'] === 'PATCH'): ?>
                                <?php echo method_field('PATCH'); ?>
                            <?php endif; ?>

                            <button type="submit"
                                class="inline-flex items-center justify-center w-full px-6 py-2 bg-<?php echo e($actionItem['color']); ?>-600 border border-transparent text-sm rounded-full border-2 font-semibold text-white hover:bg-<?php echo e($actionItem['color']); ?>-700 active:bg-<?php echo e($actionItem['color']); ?>-800 focus:outline-none focus:ring-2 focus:ring-<?php echo e($actionItem['color']); ?>-500 focus:ring-offset-2 transition ease-in-out duration-150 no-underline <?php echo e($compact ? 'text-sm' : ''); ?> leading-4 text-start gap-1 max-h-14 max-w-44"
                                onclick="return confirm('¿Estás seguro de que deseas <?php echo e(strtolower($actionItem['label'])); ?>?')">
                                <i class="fas fa-<?php echo e($actionItem['icon']); ?> <?php echo e($showLabels ? 'mr-2' : ''); ?>"></i>
                                <?php if($showLabels): ?>
                                    <?php echo e($actionItem['label']); ?>

                                <?php endif; ?>
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="<?php echo e($compact ? '' : 'bg-gray-50 rounded-2xl border border-gray-200'); ?>  max-w-44 max-h-max">
                    <button type="button" disabled
                        class="inline-flex items-center justify-center w-full px-6 py-2 bg-gray-400 border border-transparent text-sm font-semibold text-white cursor-not-allowed <?php echo e($compact ? 'text-sm' : ''); ?> leading-4 text-start gap-1 rounded-2xl max-w-44"
                        title="<?php echo e($actionItem['action'] === 'resolve' ? 'Debe agregar al menos una evidencia antes de resolver' : 'Acción no disponible en este momento'); ?>">
                        <i class="fas fa-<?php echo e($actionItem['icon']); ?> <?php echo e($showLabels ? 'mr-2' : ''); ?>"></i>
                        <?php if($showLabels): ?>
                            <?php echo e($actionItem['label']); ?>

                        <?php endif; ?>
                    </button>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php elseif($disabled): ?>
    <div class="bg-gray-100 border border-gray-300 rounded-2xl text-center">
        <p class="text-gray-600">
            <i class="fas fa-lock mr-2"></i>
            Las acciones no están disponibles en este momento
        </p>
    </div>
<?php else: ?>
    <div class="bg-blue-50 border border-blue-300 rounded-2xl text-center">
        <p class="text-blue-700">
            <i class="fas fa-check-circle mr-2"></i>
            No hay acciones disponibles para el estado: <strong><?php echo e($currentStatus); ?></strong>
        </p>
    </div>
<?php endif; ?>

<?php if(!$disabled): ?>
    <?php if($currentStatus === 'PAUSADA'): ?>
        <?php echo $__env->make('components.service-requests.show.header.vencimiento-modal', [
            'serviceRequest' => $serviceRequest,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('components.service-requests.show.header.resume-modal', [
            'serviceRequest' => $serviceRequest,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
    <?php if($currentStatus === 'PENDIENTE' && !$serviceRequest->assigned_to): ?>
        <?php echo $__env->make('components.service-requests.show.header.assign-technician-modal', [
            'serviceRequest' => $serviceRequest,
            'technicians' => $technicians,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
    <?php if($currentStatus === 'PENDIENTE' && $serviceRequest->assigned_to): ?>
        <?php echo $__env->make('components.service-requests.show.header.accept-modal', [
            'serviceRequest' => $serviceRequest,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
    <?php if($currentStatus === 'PENDIENTE'): ?>
        <?php echo $__env->make('components.service-requests.show.header.reject-modal', [
            'serviceRequest' => $serviceRequest,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
    
    <?php if($currentStatus === 'ACEPTADA'): ?>
        <?php echo $__env->make('components.service-requests.show.header.start-modal', [
            'serviceRequest' => $serviceRequest,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
    <?php if($currentStatus === 'EN_PROCESO'): ?>
        <?php echo $__env->make('components.service-requests.show.header.pause-modal', [
            'serviceRequest' => $serviceRequest,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        
        <?php echo $__env->make('components.service-requests.show.header.resolve-modal', [
            'serviceRequest' => $serviceRequest,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
    <?php if($currentStatus === 'RESUELTA'): ?>
        <?php echo $__env->make('components.service-requests.show.header.reopen-modal', [
            'serviceRequest' => $serviceRequest,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        
        <?php echo $__env->make('components.service-requests.show.header.close-modal', [
            'serviceRequest' => $serviceRequest,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sdm\resources\views/components/service-requests/show/header/workflow-actions.blade.php ENDPATH**/ ?>