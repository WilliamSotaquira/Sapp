<?php $__env->startSection('title', 'Servicios'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-6">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-2xl font-bold text-gray-800">Servicios</h1>
            <p class="text-gray-600 mt-1">Gestión de servicios y sus configuraciones</p>
        </div>
        <a href="<?php echo e(route('services.create')); ?>"
           class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition duration-200 flex items-center">
            <i class="fas fa-plus mr-2"></i>Nuevo Servicio
        </a>
    </div>

    <!-- Alertas -->
    <?php if(session('success')): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded">
            <div class="flex items-center">
                <i class="fas fa-check-circle mr-2"></i>
                <span><?php echo e(session('success')); ?></span>
            </div>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded">
            <div class="flex items-center">
                <i class="fas fa-exclamation-circle mr-2"></i>
                <span><?php echo e(session('error')); ?></span>
            </div>
        </div>
    <?php endif; ?>

    <!-- Filtros y Búsqueda -->
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Buscar</label>
                <input type="text" id="searchInput" placeholder="Buscar servicios..."
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Familia</label>
                <select id="familyFilter" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <option value="">Todas las familias</option>
                    <?php $__currentLoopData = $services->pluck('family')->unique()->filter(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($family->id); ?>"><?php echo e($family->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Estado</label>
                <select id="statusFilter" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <option value="">Todos los estados</option>
                    <option value="active">Activos</option>
                    <option value="inactive">Inactivos</option>
                </select>
            </div>
        </div>
    </div>

    <!-- Tabla de Servicios -->
    <div class="bg-white shadow-md rounded-lg overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer sortable" data-sort="name">
                            <div class="flex items-center">
                                <span>Nombre</span>
                                <i class="fas fa-sort ml-1 text-gray-400"></i>
                            </div>
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer sortable" data-sort="code">
                            <div class="flex items-center">
                                <span>Código</span>
                                <i class="fas fa-sort ml-1 text-gray-400"></i>
                            </div>
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer sortable" data-sort="family">
                            <div class="flex items-center">
                                <span>Familia</span>
                                <i class="fas fa-sort ml-1 text-gray-400"></i>
                            </div>
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Sub-Servicios
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer sortable" data-sort="status">
                            <div class="flex items-center">
                                <span>Estado</span>
                                <i class="fas fa-sort ml-1 text-gray-400"></i>
                            </div>
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Acciones
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200" id="servicesTable">
                    <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="service-row hover:bg-gray-50 transition duration-150"
                        data-name="<?php echo e(strtolower($service->name)); ?>"
                        data-code="<?php echo e(strtolower($service->code)); ?>"
                        data-family="<?php echo e($service->family ? strtolower($service->family->name) : ''); ?>"
                        data-status="<?php echo e($service->is_active ? 'active' : 'inactive'); ?>">
                        <td class="px-6 py-4">
                            <div class="flex items-center">
                                <div class="flex-shrink-0 h-10 w-10 bg-blue-100 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-cog text-blue-600"></i>
                                </div>
                                <div class="ml-4">
                                    <div class="text-sm font-medium text-gray-900"><?php echo e($service->name); ?></div>
                                    <?php if($service->description): ?>
                                    <div class="text-sm text-gray-500"><?php echo e(Str::limit($service->description, 60)); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800 border border-blue-200">
                                <i class="fas fa-hashtag mr-1"></i>
                                <?php echo e($service->code); ?>

                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <?php if($service->family): ?>
                            <div class="flex items-center">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800 mr-2">
                                    <?php echo e($service->family->code); ?>

                                </span>
                                <span class="text-sm text-gray-700"><?php echo e($service->family->name); ?></span>
                            </div>
                            <?php else: ?>
                            <span class="text-sm text-gray-400 italic">Sin familia</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center">
                                <span class="text-sm text-gray-700 font-medium mr-2">
                                    <?php echo e($service->sub_services_count ?? 0); ?>

                                </span>
                                <span class="text-sm text-gray-500">sub-servicios</span>
                                <?php if(($service->sub_services_count ?? 0) > 0): ?>
                                <a href="<?php echo e(route('services.show', $service)); ?>"
                                   class="ml-2 text-blue-500 hover:text-blue-700 text-xs"
                                   title="Ver sub-servicios">
                                    <i class="fas fa-list"></i>
                                </a>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium <?php echo e($service->is_active ? 'bg-green-100 text-green-800 border border-green-200' : 'bg-red-100 text-red-800 border border-red-200'); ?>">
                                <i class="fas fa-circle mr-1 text-<?php echo e($service->is_active ? 'green' : 'red'); ?>-500" style="font-size: 6px;"></i>
                                <?php echo e($service->is_active ? 'Activo' : 'Inactivo'); ?>

                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center space-x-2">
                                <a href="<?php echo e(route('services.show', $service)); ?>"
                                   class="text-blue-500 hover:text-blue-700 p-2 rounded-lg hover:bg-blue-50 transition duration-200"
                                   title="Ver detalles">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="<?php echo e(route('services.edit', $service)); ?>"
                                   class="text-green-500 hover:text-green-700 p-2 rounded-lg hover:bg-green-50 transition duration-200"
                                   title="Editar servicio">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('services.destroy', $service)); ?>" method="POST" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit"
                                            class="text-red-500 hover:text-red-700 p-2 rounded-lg hover:bg-red-50 transition duration-200"
                                            onclick="return confirm('¿Está seguro de eliminar el servicio \"<?php echo e($service->name); ?>\"? Esta acción no se puede deshacer.')"
                                            title="Eliminar servicio">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="px-6 py-12 text-center">
                            <div class="flex flex-col items-center justify-center text-gray-400">
                                <i class="fas fa-cogs text-4xl mb-3"></i>
                                <p class="text-lg font-medium mb-1">No hay servicios registrados</p>
                                <p class="text-sm">Comienza creando tu primer servicio</p>
                                <a href="<?php echo e(route('services.create')); ?>"
                                   class="mt-4 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg inline-flex items-center">
                                    <i class="fas fa-plus mr-2"></i>Crear Primer Servicio
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Información de resultados -->
        <?php if($services->count() > 0): ?>
        <div class="bg-gray-50 px-6 py-3 border-t border-gray-200">
            <div class="flex justify-between items-center text-sm text-gray-600">
                <div>
                    Mostrando <span class="font-medium"><?php echo e($services->count()); ?></span> servicios
                </div>
                <div class="flex items-center space-x-4">
                    <span id="activeCount" class="flex items-center">
                        <i class="fas fa-circle text-green-500 mr-1" style="font-size: 6px;"></i>
                        <span class="font-medium"><?php echo e($services->where('is_active', true)->count()); ?></span> activos
                    </span>
                    <span id="inactiveCount" class="flex items-center">
                        <i class="fas fa-circle text-red-500 mr-1" style="font-size: 6px;"></i>
                        <span class="font-medium"><?php echo e($services->where('is_active', false)->count()); ?></span> inactivos
                    </span>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    const familyFilter = document.getElementById('familyFilter');
    const statusFilter = document.getElementById('statusFilter');
    const servicesTable = document.getElementById('servicesTable');
    const serviceRows = document.querySelectorAll('.service-row');

    function filterServices() {
        const searchTerm = searchInput.value.toLowerCase();
        const familyValue = familyFilter.value;
        const statusValue = statusFilter.value;

        serviceRows.forEach(row => {
            const name = row.getAttribute('data-name');
            const code = row.getAttribute('data-code');
            const family = row.getAttribute('data-family');
            const status = row.getAttribute('data-status');

            const matchesSearch = name.includes(searchTerm) || code.includes(searchTerm);
            const matchesFamily = !familyValue || family.includes(familyValue.toLowerCase());
            const matchesStatus = !statusValue || status === statusValue;

            if (matchesSearch && matchesFamily && matchesStatus) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }

    // Event listeners para filtros
    searchInput.addEventListener('input', filterServices);
    familyFilter.addEventListener('change', filterServices);
    statusFilter.addEventListener('change', filterServices);

    // Ordenamiento simple
    document.querySelectorAll('.sortable').forEach(header => {
        header.addEventListener('click', function() {
            const sortBy = this.getAttribute('data-sort');
            // Implementar lógica de ordenamiento aquí si es necesario
            console.log('Ordenar por:', sortBy);
        });
    });
});
</script>
<?php $__env->stopPush(); ?>

<style>
.sortable:hover {
    background-color: #f9fafb;
}

.service-row {
    transition: all 0.2s ease-in-out;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sdm\resources\views/services/index.blade.php ENDPATH**/ ?>