<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['request', 'compact' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['request', 'compact' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="flex items-center gap-1">
    <a href="<?php echo e(route('service-requests.show', $request)); ?>"
       class="text-blue-600 hover:text-blue-800 p-1 rounded transition-colors duration-150"
       title="Ver detalles"
       aria-label="Ver detalles de la solicitud <?php echo e($request->ticket_number); ?>">
        <i class="fas fa-eye <?php echo e($compact ? 'text-xs' : 'text-sm'); ?>"></i>
    </a>

    <?php if($request->status === 'PENDIENTE'): ?>
        <button class="text-green-600 hover:text-green-800 p-1 rounded transition-colors duration-150"
                title="Aceptar solicitud"
                aria-label="Aceptar solicitud <?php echo e($request->ticket_number); ?>">
            <i class="fas fa-check <?php echo e($compact ? 'text-xs' : 'text-sm'); ?>"></i>
        </button>
    <?php endif; ?>

    <?php if(in_array($request->status, ['ACEPTADA', 'EN_PROCESO'])): ?>
        <button class="text-purple-600 hover:text-purple-800 p-1 rounded transition-colors duration-150"
                title="Marcar en progreso"
                aria-label="Marcar en progreso solicitud <?php echo e($request->ticket_number); ?>">
            <i class="fas fa-cog <?php echo e($compact ? 'text-xs' : 'text-sm'); ?>"></i>
        </button>
    <?php endif; ?>

    <button class="text-gray-500 hover:text-gray-700 p-1 rounded transition-colors duration-150"
            title="Más opciones"
            aria-label="Más opciones para solicitud <?php echo e($request->ticket_number); ?>">
        <i class="fas fa-ellipsis-h <?php echo e($compact ? 'text-xs' : 'text-sm'); ?>"></i>
    </button>
</div>
<?php /**PATH C:\xampp\htdocs\sdm\resources\views/components/service-requests/index/content/table-actions.blade.php ENDPATH**/ ?>