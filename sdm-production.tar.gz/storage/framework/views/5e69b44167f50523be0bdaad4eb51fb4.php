<?php $__env->startSection('title', "Solicitud {$serviceRequest->ticket_number}"); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <nav class="flex" aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-3">
            <li class="inline-flex items-center">
                <a href="<?php echo e(url('/dashboard')); ?>" class="text-blue-600 hover:text-blue-700">Dashboard</a>
            </li>
            <li class="inline-flex items-center">
                <i class="fas fa-chevron-right text-gray-400 mx-2"></i>
                <a href="<?php echo e(route('service-requests.index')); ?>" class="text-blue-600 hover:text-blue-700">Solicitudes de
                    Servicio</a>
            </li>
            <li aria-current="page">
                <div class="flex items-center">
                    <i class="fas fa-chevron-right text-gray-400 mx-2"></i>
                    <span class="text-gray-500">Solicitud #<?php echo e($serviceRequest->ticket_number); ?></span>
                </div>
            </li>
        </ol>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="space-y-6">
        <!-- Header Principal con botón de edición -->
        <div class="flex justify-between items-center flex-wrap gap-4">
            <?php if (isset($component)) { $__componentOriginal347473266e0839105190a23a50575f2e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal347473266e0839105190a23a50575f2e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.show.header.main-header','data' => ['serviceRequest' => $serviceRequest,'technicians' => $technicians]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.show.header.main-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['serviceRequest' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($serviceRequest),'technicians' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($technicians)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal347473266e0839105190a23a50575f2e)): ?>
<?php $attributes = $__attributesOriginal347473266e0839105190a23a50575f2e; ?>
<?php unset($__attributesOriginal347473266e0839105190a23a50575f2e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal347473266e0839105190a23a50575f2e)): ?>
<?php $component = $__componentOriginal347473266e0839105190a23a50575f2e; ?>
<?php unset($__componentOriginal347473266e0839105190a23a50575f2e); ?>
<?php endif; ?>
        </div>

        <!-- Tarjetas de Información -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <?php if (isset($component)) { $__componentOriginal76353e60f6f19f35a3600ceab3bb216e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal76353e60f6f19f35a3600ceab3bb216e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.show.info-cards.service-info','data' => ['serviceRequest' => $serviceRequest]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.show.info-cards.service-info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['serviceRequest' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($serviceRequest)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal76353e60f6f19f35a3600ceab3bb216e)): ?>
<?php $attributes = $__attributesOriginal76353e60f6f19f35a3600ceab3bb216e; ?>
<?php unset($__attributesOriginal76353e60f6f19f35a3600ceab3bb216e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76353e60f6f19f35a3600ceab3bb216e)): ?>
<?php $component = $__componentOriginal76353e60f6f19f35a3600ceab3bb216e; ?>
<?php unset($__componentOriginal76353e60f6f19f35a3600ceab3bb216e); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalbb5db0c9b13a7c95fcc8724a85ec57d5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb5db0c9b13a7c95fcc8724a85ec57d5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.show.info-cards.assignment-info','data' => ['serviceRequest' => $serviceRequest]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.show.info-cards.assignment-info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['serviceRequest' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($serviceRequest)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb5db0c9b13a7c95fcc8724a85ec57d5)): ?>
<?php $attributes = $__attributesOriginalbb5db0c9b13a7c95fcc8724a85ec57d5; ?>
<?php unset($__attributesOriginalbb5db0c9b13a7c95fcc8724a85ec57d5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb5db0c9b13a7c95fcc8724a85ec57d5)): ?>
<?php $component = $__componentOriginalbb5db0c9b13a7c95fcc8724a85ec57d5; ?>
<?php unset($__componentOriginalbb5db0c9b13a7c95fcc8724a85ec57d5); ?>
<?php endif; ?>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <?php if (isset($component)) { $__componentOriginalde60ae4672476f0777dcf822344900a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalde60ae4672476f0777dcf822344900a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.show.info-cards.timelines-info','data' => ['serviceRequest' => $serviceRequest]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.show.info-cards.timelines-info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['serviceRequest' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($serviceRequest)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalde60ae4672476f0777dcf822344900a0)): ?>
<?php $attributes = $__attributesOriginalde60ae4672476f0777dcf822344900a0; ?>
<?php unset($__attributesOriginalde60ae4672476f0777dcf822344900a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalde60ae4672476f0777dcf822344900a0)): ?>
<?php $component = $__componentOriginalde60ae4672476f0777dcf822344900a0; ?>
<?php unset($__componentOriginalde60ae4672476f0777dcf822344900a0); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal884c1f74d6738d35f0705449bcc66b13 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal884c1f74d6738d35f0705449bcc66b13 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.show.info-cards.sla-info','data' => ['serviceRequest' => $serviceRequest]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.show.info-cards.sla-info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['serviceRequest' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($serviceRequest)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal884c1f74d6738d35f0705449bcc66b13)): ?>
<?php $attributes = $__attributesOriginal884c1f74d6738d35f0705449bcc66b13; ?>
<?php unset($__attributesOriginal884c1f74d6738d35f0705449bcc66b13); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal884c1f74d6738d35f0705449bcc66b13)): ?>
<?php $component = $__componentOriginal884c1f74d6738d35f0705449bcc66b13; ?>
<?php unset($__componentOriginal884c1f74d6738d35f0705449bcc66b13); ?>
<?php endif; ?>
        </div>

        <!-- Paneles de Contenido -->
        <?php if (isset($component)) { $__componentOriginaldae8adde606e539bf293544acb660979 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae8adde606e539bf293544acb660979 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.show.content.description-panel','data' => ['serviceRequest' => $serviceRequest]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.show.content.description-panel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['serviceRequest' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($serviceRequest)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae8adde606e539bf293544acb660979)): ?>
<?php $attributes = $__attributesOriginaldae8adde606e539bf293544acb660979; ?>
<?php unset($__attributesOriginaldae8adde606e539bf293544acb660979); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae8adde606e539bf293544acb660979)): ?>
<?php $component = $__componentOriginaldae8adde606e539bf293544acb660979; ?>
<?php unset($__componentOriginaldae8adde606e539bf293544acb660979); ?>
<?php endif; ?>

        <!-- Panel de Rutas Web (solo si existen) -->
        <?php if($serviceRequest->hasWebRoutes()): ?>
            <?php if (isset($component)) { $__componentOriginal0e5e5da5658531ceb8eadb75bae74501 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0e5e5da5658531ceb8eadb75bae74501 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.show.content.web-routes-panel','data' => ['serviceRequest' => $serviceRequest]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.show.content.web-routes-panel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['serviceRequest' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($serviceRequest)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0e5e5da5658531ceb8eadb75bae74501)): ?>
<?php $attributes = $__attributesOriginal0e5e5da5658531ceb8eadb75bae74501; ?>
<?php unset($__attributesOriginal0e5e5da5658531ceb8eadb75bae74501); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0e5e5da5658531ceb8eadb75bae74501)): ?>
<?php $component = $__componentOriginal0e5e5da5658531ceb8eadb75bae74501; ?>
<?php unset($__componentOriginal0e5e5da5658531ceb8eadb75bae74501); ?>
<?php endif; ?>
        <?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal3775c1fb7e317c3707013c9b7e982d6f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3775c1fb7e317c3707013c9b7e982d6f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.show.content.actions-panel','data' => ['serviceRequest' => $serviceRequest]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.show.content.actions-panel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['serviceRequest' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($serviceRequest)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3775c1fb7e317c3707013c9b7e982d6f)): ?>
<?php $attributes = $__attributesOriginal3775c1fb7e317c3707013c9b7e982d6f; ?>
<?php unset($__attributesOriginal3775c1fb7e317c3707013c9b7e982d6f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3775c1fb7e317c3707013c9b7e982d6f)): ?>
<?php $component = $__componentOriginal3775c1fb7e317c3707013c9b7e982d6f; ?>
<?php unset($__componentOriginal3775c1fb7e317c3707013c9b7e982d6f); ?>
<?php endif; ?>

        <!-- Sistema de Evidencias -->
        <?php if (isset($component)) { $__componentOriginalb51d2fc314441cdda9000a5d2d9cba04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb51d2fc314441cdda9000a5d2d9cba04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.show.evidences.evidence-gallery','data' => ['serviceRequest' => $serviceRequest]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.show.evidences.evidence-gallery'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['serviceRequest' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($serviceRequest)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb51d2fc314441cdda9000a5d2d9cba04)): ?>
<?php $attributes = $__attributesOriginalb51d2fc314441cdda9000a5d2d9cba04; ?>
<?php unset($__attributesOriginalb51d2fc314441cdda9000a5d2d9cba04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb51d2fc314441cdda9000a5d2d9cba04)): ?>
<?php $component = $__componentOriginalb51d2fc314441cdda9000a5d2d9cba04; ?>
<?php unset($__componentOriginalb51d2fc314441cdda9000a5d2d9cba04); ?>
<?php endif; ?>

        <!-- Historial y Timeline -->
        
    </div>

    <!-- Modal de vista previa para evidencias -->
    <?php if (isset($component)) { $__componentOriginal815432dcc74594a7e7155e58894ec03a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal815432dcc74594a7e7155e58894ec03a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.show.evidences.evidence-preview','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.show.evidences.evidence-preview'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal815432dcc74594a7e7155e58894ec03a)): ?>
<?php $attributes = $__attributesOriginal815432dcc74594a7e7155e58894ec03a; ?>
<?php unset($__attributesOriginal815432dcc74594a7e7155e58894ec03a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal815432dcc74594a7e7155e58894ec03a)): ?>
<?php $component = $__componentOriginal815432dcc74594a7e7155e58894ec03a; ?>
<?php unset($__componentOriginal815432dcc74594a7e7155e58894ec03a); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        /* Timeline Styles */
        .timeline-item::before {
            content: '';
            position: absolute;
            left: -2rem;
            top: 1.5rem;
            width: 1rem;
            height: 2px;
            background: #e5e7eb;
        }

        .group:hover .timeline-dot {
            transform: scale(1.1);
            transition: transform 0.2s ease-in-out;
        }

        /* Smooth transitions for timeline */
        .timeline-enter {
            opacity: 0;
            transform: translateX(-20px);
        }

        .timeline-enter-active {
            opacity: 1;
            transform: translateX(0);
            transition: opacity 0.3s, transform 0.3s;
        }

        /* Estilos para evidencias */
        .evidence-image {
            max-width: 100%;
            height: auto;
            border-radius: 0.5rem;
        }

        .evidence-preview:hover {
            transform: scale(1.02);
            transition: transform 0.2s ease-in-out;
        }

        @media (max-width: 768px) {
            .timeline-item::before {
                left: -1.5rem;
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Service Request Show page loaded - Evidences system ready');

            // ✅ MEJOR OPCIÓN: Separar completamente el JS del Blade
            const evidenceCount = {
                {
                    $serviceRequest - > evidences ? $serviceRequest - > evidences - > count() : 0
                }
            };
            if (evidenceCount > 0) {
                console.log('Evidencias cargadas:', evidenceCount);
            } else {
                console.log('No hay evidencias para esta solicitud');
            }
            f

            // Script para manejar errores de carga de imágenes
            document.addEventListener('error', function(e) {
                if (e.target.tagName === 'IMG' && e.target.classList.contains('evidence-image')) {
                    console.warn('Error cargando imagen de evidencia:', e.target.src);
                    e.target.style.display = 'none';
                    // Mostrar placeholder de error
                    const parent = e.target.parentElement;
                    if (parent) {
                        parent.innerHTML = `
                        <div class="w-full h-32 bg-gray-200 rounded-lg flex items-center justify-center">
                            <i class="fas fa-exclamation-triangle text-gray-400 text-2xl"></i>
                        </div>
                        <p class="text-xs text-gray-500 mt-2 text-center">Error cargando imagen</p>
                    `;
                    }
                }
            }, true);
        });

        // ✅ FUNCIONES GLOBALES para el modal de vista previa
        function openPreview(fileUrl, fileName) {
            const modal = document.getElementById('previewModal');
            const image = document.getElementById('previewImage');
            const title = document.getElementById('previewTitle');
            const info = document.getElementById('previewInfo');
            const downloadLink = document.getElementById('previewDownload');

            // Mostrar loader mientras carga
            image.style.display = 'none';
            modal.classList.remove('hidden');

            const tempImage = new Image();
            tempImage.onload = function() {
                image.src = fileUrl;
                image.style.display = 'block';
                title.textContent = fileName;
                info.textContent = `Vista previa de ${fileName}`;
                downloadLink.href = fileUrl;
                downloadLink.download = fileName;
            };

            tempImage.onerror = function() {
                image.style.display = 'none';
                title.textContent = 'Error';
                info.textContent = 'No se pudo cargar la imagen';
                downloadLink.style.display = 'none';
            };

            tempImage.src = fileUrl;
            document.body.style.overflow = 'hidden';
        }

        function closePreview() {
            const modal = document.getElementById('previewModal');
            modal.classList.add('hidden');
            document.body.style.overflow = 'auto';
        }

        // Cerrar modal con ESC
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closePreview();
            }
        });

        // Cerrar modal haciendo click fuera
        document.addEventListener('click', function(e) {
            const modal = document.getElementById('previewModal');
            if (e.target === modal) {
                closePreview();
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sdm\resources\views/service-requests/show.blade.php ENDPATH**/ ?>