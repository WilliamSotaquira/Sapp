<?php $__env->startSection('title', 'Solicitudes de Servicio'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <nav class="flex" aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-3">
            <li class="inline-flex items-center">
                <a href="<?php echo e(url('/dashboard')); ?>" class="text-blue-600 hover:text-blue-700">Dashboard</a>
            </li>
            <li aria-current="page">
                <div class="flex items-center">
                    <i class="fas fa-chevron-right text-gray-400 mx-2"></i>
                    <span class="text-gray-500">Solicitudes de Servicio</span>
                </div>
            </li>
        </ol>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Header Principal -->
    <?php if (isset($component)) { $__componentOriginala276a41a9fbff1b8fefd6a15f425dd31 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala276a41a9fbff1b8fefd6a15f425dd31 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.index.header.main-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.index.header.main-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala276a41a9fbff1b8fefd6a15f425dd31)): ?>
<?php $attributes = $__attributesOriginala276a41a9fbff1b8fefd6a15f425dd31; ?>
<?php unset($__attributesOriginala276a41a9fbff1b8fefd6a15f425dd31); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala276a41a9fbff1b8fefd6a15f425dd31)): ?>
<?php $component = $__componentOriginala276a41a9fbff1b8fefd6a15f425dd31; ?>
<?php unset($__componentOriginala276a41a9fbff1b8fefd6a15f425dd31); ?>
<?php endif; ?>

    <div class="space-y-6">
        <!-- Fila 1: Estadísticas y Acción Principal -->
        <div class="grid grid-cols-1 lg:grid-cols-5 gap-6">

            <!-- Tarjeta 1: Nueva Solicitud -->
            <?php if (isset($component)) { $__componentOriginal90bcae437d438794af58a11336f6dcde = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal90bcae437d438794af58a11336f6dcde = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.index.stats-cards.create-action','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.index.stats-cards.create-action'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal90bcae437d438794af58a11336f6dcde)): ?>
<?php $attributes = $__attributesOriginal90bcae437d438794af58a11336f6dcde; ?>
<?php unset($__attributesOriginal90bcae437d438794af58a11336f6dcde); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal90bcae437d438794af58a11336f6dcde)): ?>
<?php $component = $__componentOriginal90bcae437d438794af58a11336f6dcde; ?>
<?php unset($__componentOriginal90bcae437d438794af58a11336f6dcde); ?>
<?php endif; ?>

            <!-- Tarjeta 2: Críticas -->
            <?php if (isset($component)) { $__componentOriginal28452ac05144de64afeff98e99991d3c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28452ac05144de64afeff98e99991d3c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.index.stats-cards.critical-stats','data' => ['count' => $criticalCount ?? 0]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.index.stats-cards.critical-stats'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($criticalCount ?? 0)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28452ac05144de64afeff98e99991d3c)): ?>
<?php $attributes = $__attributesOriginal28452ac05144de64afeff98e99991d3c; ?>
<?php unset($__attributesOriginal28452ac05144de64afeff98e99991d3c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28452ac05144de64afeff98e99991d3c)): ?>
<?php $component = $__componentOriginal28452ac05144de64afeff98e99991d3c; ?>
<?php unset($__componentOriginal28452ac05144de64afeff98e99991d3c); ?>
<?php endif; ?>

            <!-- Tarjeta 3: Pendientes -->
            <?php if (isset($component)) { $__componentOriginalea1714f42d2a7ef83ded32ed8d041e16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalea1714f42d2a7ef83ded32ed8d041e16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.index.stats-cards.pending-stats','data' => ['count' => $pendingCount ?? 0]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.index.stats-cards.pending-stats'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pendingCount ?? 0)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalea1714f42d2a7ef83ded32ed8d041e16)): ?>
<?php $attributes = $__attributesOriginalea1714f42d2a7ef83ded32ed8d041e16; ?>
<?php unset($__attributesOriginalea1714f42d2a7ef83ded32ed8d041e16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalea1714f42d2a7ef83ded32ed8d041e16)): ?>
<?php $component = $__componentOriginalea1714f42d2a7ef83ded32ed8d041e16; ?>
<?php unset($__componentOriginalea1714f42d2a7ef83ded32ed8d041e16); ?>
<?php endif; ?>

            <!-- Tarjeta 4: Cerradas -->
            <?php if (isset($component)) { $__componentOriginal163913a5e3c463f89e4c1575e4ed74fc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal163913a5e3c463f89e4c1575e4ed74fc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.index.stats-cards.closed-stats','data' => ['count' => $closedCount ?? 0]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.index.stats-cards.closed-stats'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($closedCount ?? 0)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal163913a5e3c463f89e4c1575e4ed74fc)): ?>
<?php $attributes = $__attributesOriginal163913a5e3c463f89e4c1575e4ed74fc; ?>
<?php unset($__attributesOriginal163913a5e3c463f89e4c1575e4ed74fc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal163913a5e3c463f89e4c1575e4ed74fc)): ?>
<?php $component = $__componentOriginal163913a5e3c463f89e4c1575e4ed74fc; ?>
<?php unset($__componentOriginal163913a5e3c463f89e4c1575e4ed74fc); ?>
<?php endif; ?>

            <!-- Tarjeta 5: Total -->
            <?php if (isset($component)) { $__componentOriginal5d2ddb3b2d018b2ae9ffffcbb17d95ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5d2ddb3b2d018b2ae9ffffcbb17d95ea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.index.stats-cards.total-stats','data' => ['count' => $serviceRequests->total()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.index.stats-cards.total-stats'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($serviceRequests->total())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5d2ddb3b2d018b2ae9ffffcbb17d95ea)): ?>
<?php $attributes = $__attributesOriginal5d2ddb3b2d018b2ae9ffffcbb17d95ea; ?>
<?php unset($__attributesOriginal5d2ddb3b2d018b2ae9ffffcbb17d95ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5d2ddb3b2d018b2ae9ffffcbb17d95ea)): ?>
<?php $component = $__componentOriginal5d2ddb3b2d018b2ae9ffffcbb17d95ea; ?>
<?php unset($__componentOriginal5d2ddb3b2d018b2ae9ffffcbb17d95ea); ?>
<?php endif; ?>

        </div>

        <!-- Fila 2: Filtros y Búsqueda -->
        <?php if (isset($component)) { $__componentOriginalb9fa4508cdc3df095cef8dfe7ebaca15 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb9fa4508cdc3df095cef8dfe7ebaca15 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.index.filters.filters-panel','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.index.filters.filters-panel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb9fa4508cdc3df095cef8dfe7ebaca15)): ?>
<?php $attributes = $__attributesOriginalb9fa4508cdc3df095cef8dfe7ebaca15; ?>
<?php unset($__attributesOriginalb9fa4508cdc3df095cef8dfe7ebaca15); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb9fa4508cdc3df095cef8dfe7ebaca15)): ?>
<?php $component = $__componentOriginalb9fa4508cdc3df095cef8dfe7ebaca15; ?>
<?php unset($__componentOriginalb9fa4508cdc3df095cef8dfe7ebaca15); ?>
<?php endif; ?>

        <!-- Fila 3: Lista de Solicitudes -->
        <?php if (isset($component)) { $__componentOriginal31998e373a6d7db23aee8bf5b42fdfd8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal31998e373a6d7db23aee8bf5b42fdfd8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.index.content.requests-table','data' => ['serviceRequests' => $serviceRequests]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.index.content.requests-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['serviceRequests' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($serviceRequests)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal31998e373a6d7db23aee8bf5b42fdfd8)): ?>
<?php $attributes = $__attributesOriginal31998e373a6d7db23aee8bf5b42fdfd8; ?>
<?php unset($__attributesOriginal31998e373a6d7db23aee8bf5b42fdfd8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal31998e373a6d7db23aee8bf5b42fdfd8)): ?>
<?php $component = $__componentOriginal31998e373a6d7db23aee8bf5b42fdfd8; ?>
<?php unset($__componentOriginal31998e373a6d7db23aee8bf5b42fdfd8); ?>
<?php endif; ?>

        <!-- Fila 4: Paginación -->
        <?php if($serviceRequests->hasPages()): ?>
            <?php if (isset($component)) { $__componentOriginal67333d6c34a79d259d6c8aa08071a64a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal67333d6c34a79d259d6c8aa08071a64a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.index.content.pagination','data' => ['serviceRequests' => $serviceRequests]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.index.content.pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['serviceRequests' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($serviceRequests)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal67333d6c34a79d259d6c8aa08071a64a)): ?>
<?php $attributes = $__attributesOriginal67333d6c34a79d259d6c8aa08071a64a; ?>
<?php unset($__attributesOriginal67333d6c34a79d259d6c8aa08071a64a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal67333d6c34a79d259d6c8aa08071a64a)): ?>
<?php $component = $__componentOriginal67333d6c34a79d259d6c8aa08071a64a; ?>
<?php unset($__componentOriginal67333d6c34a79d259d6c8aa08071a64a); ?>
<?php endif; ?>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Elementos del DOM
            const statusFilter = document.getElementById('statusFilter');
            const criticalityFilter = document.getElementById('criticalityFilter');
            const applyFiltersBtn = document.getElementById('applyFilters');
            const clearFiltersBtn = document.getElementById('clearFilters');

            // Aplicar filtros
            function applyFilters() {
                const status = statusFilter.value;
                const criticality = criticalityFilter.value;
                const rows = document.querySelectorAll('tbody tr[data-status]');

                let visibleCount = 0;

                rows.forEach(row => {
                    const rowStatus = row.getAttribute('data-status');
                    const rowCriticality = row.getAttribute('data-criticality');

                    const statusMatch = !status || rowStatus === status;
                    const criticalityMatch = !criticality || rowCriticality === criticality;

                    if (statusMatch && criticalityMatch) {
                        row.style.display = '';
                        visibleCount++;
                    } else {
                        row.style.display = 'none';
                    }
                });

                // Actualizar contador
                const counter = document.querySelector('.bg-blue-100');
                if (counter) {
                    counter.textContent = `${visibleCount} resultados`;
                }
            }

            // Limpiar filtros
            function clearFilters() {
                statusFilter.value = '';
                criticalityFilter.value = '';
                applyFilters();
                sessionStorage.removeItem('serviceRequests_statusFilter');
                sessionStorage.removeItem('serviceRequests_criticalityFilter');
            }

            // Event Listeners
            applyFiltersBtn.addEventListener('click', applyFilters);
            clearFiltersBtn.addEventListener('click', clearFilters);

            // Restaurar valores de filtro si existen
            const savedStatus = sessionStorage.getItem('serviceRequests_statusFilter');
            const savedCriticality = sessionStorage.getItem('serviceRequests_criticalityFilter');

            if (savedStatus) statusFilter.value = savedStatus;
            if (savedCriticality) criticalityFilter.value = savedCriticality;

            // Guardar valores de filtro
            statusFilter.addEventListener('change', () => {
                sessionStorage.setItem('serviceRequests_statusFilter', statusFilter.value);
            });

            criticalityFilter.addEventListener('change', () => {
                sessionStorage.setItem('serviceRequests_criticalityFilter', criticalityFilter.value);
            });

            // Aplicar filtros al cargar la página
            applyFilters();
        });
    </script>
<?php $__env->stopPush(); ?>

<style>
    .bg-gradient-to-br {
        background: linear-gradient(135deg, var(--tw-gradient-from), var(--tw-gradient-to));
    }

    .backdrop-blur-sm {
        backdrop-filter: blur(4px);
    }

    .transition {
        transition: all 0.2s ease-in-out;
    }

    .hover\:bg-gray-50:hover {
        background-color: rgba(249, 250, 251, 0.8);
    }

    .font-mono {
        font-family: ui-monospace, SFMono-Regular, 'SF Mono', Menlo, Monaco, Consolas, monospace;
    }
</style>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sdm\resources\views/service-requests/index.blade.php ENDPATH**/ ?>