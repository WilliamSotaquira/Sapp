<?php $__env->startSection('title', 'Lista de SLAs'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <div class="max-w-7xl mx-auto">
        <!-- Header -->
        <div class="flex justify-between items-center mb-6">
            <div>
                <h1 class="text-3xl font-bold text-gray-900">Acuerdos de Nivel de Servicio (SLAs)</h1>
                <p class="text-gray-600 mt-2">Gestión de todos los acuerdos de nivel de servicio</p>
            </div>
            <a href="<?php echo e(route('slas.create')); ?>"
               class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition duration-150 ease-in-out">
                <i class="fas fa-plus mr-2"></i>Nuevo SLA
            </a>
        </div>

        <!-- Mensajes de éxito/error -->
        <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
            <i class="fas fa-check-circle mr-2"></i><?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
            <i class="fas fa-exclamation-circle mr-2"></i><?php echo e(session('error')); ?>

        </div>
        <?php endif; ?>

        <!-- Tabla de SLAs -->
        <div class="bg-white shadow-md rounded-lg overflow-hidden">
            <?php if($slas->count() > 0): ?>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Nombre
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Servicio
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Nivel
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Tiempos
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Disponibilidad
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Estado
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Acciones
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__currentLoopData = $slas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4">
                                <div class="text-sm font-medium text-gray-900"><?php echo e($sla->name); ?></div>
                                <?php if($sla->description): ?>
                                <div class="text-sm text-gray-500 truncate max-w-xs"><?php echo e(Str::limit($sla->description, 50)); ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4">
                                <div class="text-sm text-gray-900">
                                    <?php echo e($sla->serviceSubservice->name ?? 'N/A'); ?>

                                </div>
                            </td>
                            <td class="px-6 py-4">
                                <?php
                                    $criticalityColors = [
                                        'BAJA' => 'bg-green-100 text-green-800',
                                        'MEDIA' => 'bg-yellow-100 text-yellow-800',
                                        'ALTA' => 'bg-orange-100 text-orange-800',
                                        'CRITICA' => 'bg-red-100 text-red-800'
                                    ];
                                    $color = $criticalityColors[$sla->criticality_level] ?? 'bg-gray-100 text-gray-800';
                                ?>
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo e($color); ?>">
                                    <?php echo e($sla->criticality_level); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4 text-sm text-gray-900">
                                <div>Respuesta: <strong><?php echo e($sla->response_time_hours); ?>h</strong></div>
                                <div>Resolución: <strong><?php echo e($sla->resolution_time_hours); ?>h</strong></div>
                            </td>
                            <td class="px-6 py-4 text-sm text-gray-900">
                                <strong><?php echo e($sla->availability_percentage); ?>%</strong>
                            </td>
                            <td class="px-6 py-4">
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo e($sla->is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                                    <?php echo e($sla->is_active ? 'Activo' : 'Inactivo'); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4 text-sm font-medium">
                                <div class="flex space-x-3">
                                    <a href="<?php echo e(route('slas.show', $sla)); ?>" class="text-green-600 hover:text-green-900" title="Ver">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('slas.edit', $sla)); ?>" class="text-blue-600 hover:text-blue-900" title="Editar">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="<?php echo e(route('slas.destroy', $sla)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-600 hover:text-red-900" onclick="return confirm('¿Está seguro de eliminar este SLA?')" title="Eliminar">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="p-8 text-center">
                <i class="fas fa-file-contract text-gray-400 text-4xl mb-4"></i>
                <h3 class="text-lg font-medium text-gray-900 mb-2">No hay SLAs creados</h3>
                <p class="text-gray-500 mb-4">Comience creando el primer acuerdo de nivel de servicio.</p>
                <a href="<?php echo e(route('slas.create')); ?>" class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md">
                    Crear Primer SLA
                </a>
            </div>
            <?php endif; ?>
        </div>

        <!-- Paginación -->
        <?php if($slas->hasPages()): ?>
        <div class="mt-6">
            <?php echo e($slas->links()); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sdm\resources\views/slas/index.blade.php ENDPATH**/ ?>