
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['criticality']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['criticality']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $criticalityConfig = [
        'BAJA' => [
            'color' => 'bg-green-100 text-green-800 border-green-300',
            'icon' => 'arrow-down',
            'text' => 'Baja'
        ],
        'MEDIA' => [
            'color' => 'bg-yellow-100 text-yellow-800 border-yellow-300',
            'icon' => 'minus',
            'text' => 'Media'
        ],
        'ALTA' => [
            'color' => 'bg-orange-100 text-orange-800 border-orange-300',
            'icon' => 'exclamation-triangle',
            'text' => 'Alta'
        ],
        'URGENTE' => [
            'color' => 'bg-red-100 text-red-800 border-red-300',
            'icon' => 'exclamation-circle',
            'text' => 'Urgente'
        ],
        'CRITICA' => [
            'color' => 'bg-red-100 text-red-800 border-red-300',
            'icon' => 'skull-crossbones',
            'text' => 'Crítica'
        ]
    ];

    $config = $criticalityConfig[$criticality] ?? $criticalityConfig['MEDIA'];
?>

<span class="inline-flex max-h-7 items-center px-4 py-1 rounded-full text-xs font-semibold border-2 <?php echo e($config['color']); ?> leading-none">
    <i class="fas fa-<?php echo e($config['icon']); ?> mr-2"></i>
    <?php echo e($config['text']); ?>

</span>
<?php /**PATH C:\xampp\htdocs\sdm\resources\views/components/service-requests/show/header/criticality-indicator.blade.php ENDPATH**/ ?>