<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['request']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['request']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<tr class="hover:bg-gray-50 text-sm"
    data-status="<?php echo e($request->status); ?>"
    data-criticality="<?php echo e($request->criticality_level); ?>"
    tabindex="0">

    <!-- Ticket -->
    <td class="px-3 py-2 whitespace-nowrap">
        <a href="<?php echo e(route('service-requests.show', $request)); ?>"
           class="font-mono text-gray-600 hover:text-gray-800 font-semibold text-xs">
            #<?php echo e($request->ticket_number); ?>

        </a>
    </td>

    <!-- Título y Descripción -->
    <td class="px-3 py-2">
        <div class="font-medium text-gray-900 text-xs"><?php echo e(Str::limit($request->title, 65)); ?></div>
        <div class="text-xs text-gray-500 mt-0.5"><?php echo e(Str::limit($request->description, 60)); ?></div>
    </td>

    <!-- Servicio -->
    <td class="px-3 py-2">
        <div class="font-medium text-xs text-gray-900"><?php echo e($request->subService->name ?? 'N/A'); ?></div>
        <div class="text-xs text-gray-500"><?php echo e($request->subService->service->family->name ?? ''); ?></div>
    </td>

    <!-- Prioridad -->
    <td class="px-3 py-2 whitespace-nowrap">
        <?php if (isset($component)) { $__componentOriginal8884af633aca9e98ad4fa5d8cc7ca9a3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8884af633aca9e98ad4fa5d8cc7ca9a3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.index.content.priority-badge','data' => ['priority' => $request->criticality_level,'compact' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.index.content.priority-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['priority' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($request->criticality_level),'compact' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8884af633aca9e98ad4fa5d8cc7ca9a3)): ?>
<?php $attributes = $__attributesOriginal8884af633aca9e98ad4fa5d8cc7ca9a3; ?>
<?php unset($__attributesOriginal8884af633aca9e98ad4fa5d8cc7ca9a3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8884af633aca9e98ad4fa5d8cc7ca9a3)): ?>
<?php $component = $__componentOriginal8884af633aca9e98ad4fa5d8cc7ca9a3; ?>
<?php unset($__componentOriginal8884af633aca9e98ad4fa5d8cc7ca9a3); ?>
<?php endif; ?>
    </td>

    <!-- Estado -->
    <td class="px-3 py-2 whitespace-nowrap">
        <?php if (isset($component)) { $__componentOriginal454f064175cc42160e61bb6017c548c9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal454f064175cc42160e61bb6017c548c9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.index.content.status-badge','data' => ['status' => $request->status,'compact' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.index.content.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($request->status),'compact' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal454f064175cc42160e61bb6017c548c9)): ?>
<?php $attributes = $__attributesOriginal454f064175cc42160e61bb6017c548c9; ?>
<?php unset($__attributesOriginal454f064175cc42160e61bb6017c548c9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal454f064175cc42160e61bb6017c548c9)): ?>
<?php $component = $__componentOriginal454f064175cc42160e61bb6017c548c9; ?>
<?php unset($__componentOriginal454f064175cc42160e61bb6017c548c9); ?>
<?php endif; ?>
    </td>

    <!-- Solicitante -->
    <td class="px-3 py-2 whitespace-nowrap">
        <div class="flex items-center space-x-2">
            <div class="w-5 h-5 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white text-xs font-bold whitespace-nowrap">
                <?php echo e(substr($request->requester->name ?? 'N', 0, 1)); ?>

            </div>
            <div class="text-xs text-gray-900 truncate max-w-[80px]">
                <?php echo e($request->requester->name ?? 'N/A'); ?>

            </div>
        </div>
    </td>

    <!-- Fecha -->
    <td class="px-3 py-2 whitespace-nowrap">
        <div class="text-xs text-gray-900"><?php echo e($request->created_at->format('d/m/Y')); ?></div>
        <div class="text-xs text-gray-500"><?php echo e($request->created_at->format('H:i')); ?></div>
    </td>

    <!-- Acciones -->
    <td class="px-3 py-2 whitespace-nowrap">
        <?php if (isset($component)) { $__componentOriginala5b2432c09d20b596cea1cb2b45c90ab = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala5b2432c09d20b596cea1cb2b45c90ab = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-requests.index.content.table-actions','data' => ['request' => $request,'compact' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-requests.index.content.table-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['request' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($request),'compact' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala5b2432c09d20b596cea1cb2b45c90ab)): ?>
<?php $attributes = $__attributesOriginala5b2432c09d20b596cea1cb2b45c90ab; ?>
<?php unset($__attributesOriginala5b2432c09d20b596cea1cb2b45c90ab); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala5b2432c09d20b596cea1cb2b45c90ab)): ?>
<?php $component = $__componentOriginala5b2432c09d20b596cea1cb2b45c90ab; ?>
<?php unset($__componentOriginala5b2432c09d20b596cea1cb2b45c90ab); ?>
<?php endif; ?>
    </td>
</tr>
<?php /**PATH C:\xampp\htdocs\sdm\resources\views/components/service-requests/index/content/table-row.blade.php ENDPATH**/ ?>