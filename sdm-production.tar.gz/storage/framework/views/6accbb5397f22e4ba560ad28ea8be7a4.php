<?php $__env->startSection('title', 'Gestión de Solicitantes'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<nav class="flex mb-4" aria-label="Breadcrumb">
    <ol class="inline-flex items-center space-x-1 md:space-x-3">
        <li class="inline-flex items-center">
            <a href="<?php echo e(url('/')); ?>" class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-red-600">
                <i class="fas fa-home mr-2"></i>
                Inicio
            </a>
        </li>
        <li aria-current="page">
            <div class="flex items-center">
                <i class="fas fa-chevron-right text-gray-400 mx-2"></i>
                <span class="ml-1 text-sm font-medium text-gray-500 md:ml-2">Gestión de Solicitantes</span>
            </div>
        </li>
    </ol>
</nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto">
    <!-- Estadísticas -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div class="bg-red-600 text-white rounded-lg shadow p-6">
            <div class="flex items-center">
                <div class="flex-shrink-0">
                    <i class="fas fa-users text-2xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-red-200">Total</p>
                    <p class="text-2xl font-bold"><?php echo e(\App\Models\Requester::count()); ?></p>
                    <p class="text-sm text-red-200">Solicitantes</p>
                </div>
            </div>
        </div>

        <div class="bg-green-600 text-white rounded-lg shadow p-6">
            <div class="flex items-center">
                <div class="flex-shrink-0">
                    <i class="fas fa-check-circle text-2xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-green-200">Activos</p>
                    <p class="text-2xl font-bold"><?php echo e(\App\Models\Requester::active()->count()); ?></p>
                    <p class="text-sm text-green-200">Solicitantes activos</p>
                </div>
            </div>
        </div>

        <div class="bg-blue-600 text-white rounded-lg shadow p-6">
            <div class="flex items-center">
                <div class="flex-shrink-0">
                    <i class="fas fa-tasks text-2xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-blue-200">Con Solicitudes</p>
                    <p class="text-2xl font-bold"><?php echo e(\App\Models\Requester::has('serviceRequests')->count()); ?></p>
                    <p class="text-sm text-blue-200">Con solicitudes creadas</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Filtros y Búsqueda -->
    <div class="bg-white rounded-lg shadow mb-6">
        <div class="p-6">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div class="flex-1">
                    <form action="<?php echo e(route('requester-management.requesters.index')); ?>" method="GET" class="flex flex-col md:flex-row gap-2">
                        <div class="flex-1 flex gap-2">
                            <input type="text" name="search"
                                   class="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent"
                                   placeholder="Buscar por nombre, email, departamento o cargo..."
                                   value="<?php echo e(request('search')); ?>">
                            <select name="status" class="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent">
                                <option value="all">Todos</option>
                                <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>Activos</option>
                                <option value="inactive" <?php echo e(request('status') == 'inactive' ? 'selected' : ''); ?>>Inactivos</option>
                            </select>
                        </div>
                        <div class="flex gap-2">
                            <button type="submit" class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors duration-200">
                                <i class="fas fa-search mr-2"></i>Buscar
                            </button>
                            <a href="<?php echo e(route('requester-management.requesters.index')); ?>"
                               class="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors duration-200">
                                Limpiar
                            </a>
                        </div>
                    </form>
                </div>
                <div>
                    <a href="<?php echo e(route('requester-management.requesters.create')); ?>"
                       class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200 flex items-center">
                        <i class="fas fa-plus mr-2"></i>Nuevo Solicitante
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Lista -->
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nombre</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contacto</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Departamento</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cargo</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Solicitudes</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $requesters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50 transition-colors duration-150">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium text-gray-900"><?php echo e($requester->name); ?></div>
                                <?php if($requester->email): ?>
                                    <div class="text-sm text-gray-500"><?php echo e($requester->email); ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php if($requester->phone): ?>
                                    <div class="flex items-center text-sm text-gray-900">
                                        <i class="fas fa-phone text-gray-400 mr-2"></i>
                                        <?php echo e($requester->phone); ?>

                                    </div>
                                <?php else: ?>
                                    <span class="text-sm text-gray-500">N/A</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?php echo e($requester->department ?? 'N/A'); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?php echo e($requester->position ?? 'N/A'); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                    <?php echo e($requester->service_requests_count); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium <?php echo e($requester->is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                                    <?php echo e($requester->is_active ? 'Activo' : 'Inactivo'); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div class="flex items-center space-x-2">
                                    <a href="<?php echo e(route('requester-management.requesters.show', $requester)); ?>"
                                       class="text-blue-600 hover:text-blue-900 transition-colors duration-200"
                                       title="Ver detalle">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('requester-management.requesters.edit', $requester)); ?>"
                                       class="text-yellow-600 hover:text-yellow-900 transition-colors duration-200"
                                       title="Editar">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="<?php echo e(route('requester-management.requesters.toggle-status', $requester)); ?>"
                                          method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit"
                                                class="text-<?php echo e($requester->is_active ? 'yellow' : 'green'); ?>-600 hover:text-<?php echo e($requester->is_active ? 'yellow' : 'green'); ?>-900 transition-colors duration-200"
                                                title="<?php echo e($requester->is_active ? 'Desactivar' : 'Activar'); ?>">
                                            <i class="fas fa-<?php echo e($requester->is_active ? 'times' : 'check'); ?>"></i>
                                        </button>
                                    </form>
                                    <?php if($requester->can_be_deleted): ?>
                                        <form action="<?php echo e(route('requester-management.requesters.destroy', $requester)); ?>"
                                              method="POST" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit"
                                                    class="text-red-600 hover:text-red-900 transition-colors duration-200"
                                                    onclick="return confirm('¿Está seguro de eliminar este solicitante?')"
                                                    title="Eliminar">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="px-6 py-12 text-center">
                                <div class="text-gray-500">
                                    <i class="fas fa-users text-4xl mb-4"></i>
                                    <p class="text-lg font-medium mb-4">No se encontraron solicitantes</p>
                                    <a href="<?php echo e(route('requester-management.requesters.create')); ?>"
                                       class="inline-flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors duration-200">
                                        <i class="fas fa-plus mr-2"></i>
                                        Crear primer solicitante
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Paginación -->
        <?php if($requesters->hasPages()): ?>
            <div class="px-6 py-4 bg-gray-50 border-t border-gray-200">
                <?php echo e($requesters->links()); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    // Scripts específicos para esta página
    document.addEventListener('DOMContentLoaded', function() {
        // Agregar funcionalidades adicionales si es necesario
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sdm\resources\views/requester-management/requesters/index.blade.php ENDPATH**/ ?>