@props(['serviceRequest'])

<!-- Descripción -->
<div class="p-6 border-b">
    <h3 class="text-lg font-semibold mb-4">Descripción</h3>
    <p class="text-gray-700 whitespace-pre-line">{{ $serviceRequest->description }}</p>
</div>
